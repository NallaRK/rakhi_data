# Pathfinder Hub — Repository Structure

This folder is a **scaffold** for the `pathfinder-hub` repository you will create in Stage 1b. Copy this structure as the initial content of `pathfinder-hub`, then populate it using the prompts/skills/agents in the rest of the zip.

## Final structure (after Stage 1b is complete)

```
pathfinder-hub/                        # the actual repo on GitHub
├── README.md                          # hub-level index (this file's eventual home)
├── manifests/
│   ├── mfe-kyc.json                   # 1 per pilot repo (6 total)
│   ├── mfe-checkout.json
│   ├── mfe-client-portal.json
│   ├── mfe-admin.json
│   ├── kyc-service.json
│   └── payment-service.json
├── wiki/
│   ├── _template/                     # skeletons — keep here, don't edit
│   │   ├── overview.md
│   │   ├── architecture.md
│   │   ├── components.md
│   │   ├── api-contracts.md
│   │   └── data-model.md
│   ├── mfe-kyc/                       # 1 folder per pilot repo
│   │   ├── overview.md
│   │   ├── architecture.md
│   │   ├── components.md
│   │   ├── api-contracts.md
│   │   └── domain-glossary.md
│   ├── kyc-service/
│   │   └── ...
│   └── ... (one folder per pilot repo)
├── cross-repo/
│   ├── _templates/                    # skeletons — keep here, don't edit
│   │   ├── dependency-map.md
│   │   ├── shared-components-registry.md
│   │   ├── api-contracts-index.md
│   │   └── domain-glossary.md
│   ├── dependency-map.md
│   ├── shared-components-registry.md
│   ├── api-contracts-index.md
│   └── domain-glossary.md
├── mcp-server/                        # the FastMCP server
│   ├── server.py
│   ├── requirements.txt
│   ├── tools/
│   │   ├── __init__.py
│   │   ├── find_repos.py
│   │   ├── get_repo_context.py
│   │   ├── impact_analysis.py
│   │   ├── enhance_story.py
│   │   ├── search_wiki.py
│   │   └── cross_repo_dependencies.py
│   └── README.md
├── scripts/
│   ├── export-deepwiki.py             # Stage 1a helper
│   └── sync-manifests.sh              # Stage 1b helper
└── .github/
    └── workflows/
        ├── sync-to-repos.yml
        ├── quarterly-refresh.yml
        └── deepwiki-export-helper.yml
```

## What goes where

| Stage | What you add | Where it goes |
|---|---|---|
| 1a | DeepWiki text exports, converted via `export-deepwiki.py` | `pathfinder-hub-structure` does NOT exist yet in Stage 1a. Per-repo `docs/wiki/` files instead. |
| 1b — start | Copy this whole `pathfinder-hub-structure/` into a new repo called `pathfinder-hub` | Top-level of the new repo |
| 1b — populate | Move per-repo `docs/wiki/` content from Stage 1a into `pathfinder-hub/wiki/{repo}/` | One folder per pilot repo |
| 1b — populate | Generate manifests using prompts/02 | `pathfinder-hub/manifests/` |
| 1b — populate | Generate cross-repo files using prompts/05 | `pathfinder-hub/cross-repo/` |
| 1b — deploy | Install MCP server dependencies and start the server | See `mcp-server/README.md` |

## How to use this scaffold

1. **Don't edit files in `_template/` or `_templates/`.** These are skeletons that the prompts/skills generate from. Editing them creates drift between Pathfinder's generation logic and what the scaffold provides.

2. **Copy templates when creating new repo wiki folders.** When adding a 7th repo to Pathfinder, copy `wiki/_template/` to `wiki/<new-repo>/` and fill in.

3. **Cross-repo files regenerate from manifests.** Don't hand-edit `cross-repo/dependency-map.md`. Run `prompts/05-build-cross-repo-docs.md` instead. The hand-edited version will be overwritten by the quarterly refresh.

4. **Workflows go in `.github/workflows/` of the hub repo.** Move the `.yml` files from `pathfinder-assets/workflows/` here.

## Critical files to set up first

When creating the actual `pathfinder-hub` repo in Stage 1b, do these in order:

1. Copy this entire scaffold into the new repo
2. Move the MCP server files into place
3. Generate the 6 manifests using `prompts/02-generate-architecture-manifest.md` (one per pilot repo)
4. Move per-repo wikis from Stage 1a's `docs/wiki/` into `pathfinder-hub/wiki/{repo}/`
5. Generate the cross-repo files using `prompts/05-build-cross-repo-docs.md`
6. Install and start the MCP server (see `mcp-server/README.md`)
7. Add `.vscode/mcp.json` to each pilot repo
8. Set up the GHA workflows in `.github/workflows/`
