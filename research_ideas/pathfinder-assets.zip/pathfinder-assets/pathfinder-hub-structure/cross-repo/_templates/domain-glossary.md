# Domain Glossary

> **How this file is maintained:** Aggregated from each repo's `pathfinder-hub/wiki/{repo}/domain-glossary.md` by running `prompts/05-build-cross-repo-docs.md`. This file is PO-facing — keep language plain.

Last updated: `<ISO date>`

Use this to find which technical components handle which business concepts.

## A

### Acceptance Criteria (AC)
The conditions that must be true for a JIRA story to be considered complete.
- **Where tracked:** JIRA tickets
- **Pathfinder usage:** `@story-analyzer` extracts AC; `@code-reviewer` builds coverage matrix

## C

### Client
A business entity that uses our platform.

> ⚠ **Common confusion:** In code, "client" sometimes refers to an HTTP client. Context matters. Code review should disambiguate.

- **Technical components:** `Client` entity (in `<backend-repo>`), `useClient` hook (multiple MFEs)
- **Related terms:** Account, Tenant

## K

### KYC (Know Your Customer)
Regulatory process for verifying client identity.
- **Frontend:** `mfe-kyc`
- **Backend:** `kyc-service`
- **Common operations:** submit, view, copy from prior, approve, reject

### KYC Submission
A completed Know-Your-Customer form submitted by a client.
- **Technical components:** `KycSubmission` document (in `kyc-service`), `KycFormContainer` (in `mfe-kyc`)
- **Lifecycle:** draft → submitted → in_review → approved / rejected

## P

### Payment
...

## Conflicts

When two repos define a term differently, both definitions surface here for resolution.

> <!-- CONFLICT: `mfe-kyc` defines "client" as the business entity; `client-service` defines "client" as the API caller. Recommend disambiguating. -->

## Generation rules

- Aggregate from `pathfinder-hub/wiki/{repo}/domain-glossary.md` files
- De-duplicate entries (multiple repos may define the same term)
- For conflicting definitions, surface BOTH; do not silently pick one
- Plain language — this is PO-facing
- Alphabetical order
- Cross-reference related terms
