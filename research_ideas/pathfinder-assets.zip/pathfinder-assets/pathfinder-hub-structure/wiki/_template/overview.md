---
last_optimized: <ISO date>
optimized_by: pathfinder-skill
verified_accurate: []
unverified: []
inaccurate_flagged: []
---

# <Repo Name> — Overview

## What is this repo

<One paragraph: business purpose, where it sits in the org, primary users.>

## Tech stack

- Language: <TypeScript / Java 17>
- Framework: <React 18 / Spring Boot 3.x>
- State / data: <Redux Toolkit + React Query / Spring Data MongoDB>
- Design system: `@your-org/design-system` (frontend only)
- Build: <Vite / Webpack / Gradle / Maven>
- CI: GitHub Actions
- Deploy: Harness

## High-level responsibility

<What this repo OWNS. What it does NOT do.>

## Entry points

- `<path/to/main.tsx>` (frontend) — Module Federation entry, mounts at `<route>`
- `<path/to/Application.java>` (backend) — Spring Boot main class

## Where to start reading

For new engineers:
1. `architecture.md` — directory structure and key decisions
2. `components.md` or `services.md` — the meaningful units
3. `api-contracts.md` — what this repo exposes / consumes

## Owner / contact

- Team: <team name>
- Slack: `#<channel>`
- PagerDuty (if backend): <service>

## Related repos

- `<related repo 1>` — <relationship>
- `<related repo 2>` — <relationship>

See `pathfinder-hub/cross-repo/dependency-map.md` for the full graph.
