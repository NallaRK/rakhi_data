---
last_optimized: <ISO date>
optimized_by: pathfinder-skill
verified_accurate: []
unverified: []
inaccurate_flagged: []
---

# Architecture — <Repo Name>

## Directory structure

```
src/
├── components/      # <one-line purpose>
├── hooks/           # <one-line purpose>
├── services/        # <one-line purpose>
├── store/           # <one-line purpose — Redux slices>
└── ...
```

## Key architectural decisions

### Decision 1: <e.g., React Query for server state, Redux for UI state only>

**Why:** <intent — derive from code comments, PR history, ADR if exists>
**When NOT to use:** <anti-pattern the team has decided against>
**Anti-pattern to flag in PR review:** <specific code shape that violates this>

### Decision 2: <e.g., Container/Presentational split for components>

**Why:** <intent>
**When NOT to use:** <anti-pattern>

### Decision 3: ...

## State management

<For frontend>
- **Server state:** React Query. See `src/queries/` for query definitions.
- **UI state (modal open, form values):** Local component state via `useState`.
- **Cross-component state:** Redux Toolkit slices in `src/store/`.
- **Why this split:** <intent>

<For backend>
- **Persistence:** Spring Data MongoDB. Documents in `src/main/java/com/yourorg/<package>/domain/`.
- **Transactions:** Spring `@Transactional` on service-layer methods only.
- **Caching:** <if any — Caffeine, Redis>.

## Module boundaries

<What is allowed to import from what. Common boundary violations to catch in review.>

## Performance considerations

- <Hotspots known to the team>
- <Patterns to avoid because they regress performance>

## Security considerations

- <Authentication mechanism>
- <Authorization patterns — who can do what>
- <PII handling rules>

## Testing strategy

<What's tested and how. Coverage expectations.>

See `pathfinder-hub/wiki/<repo-name>/components.md` (or `services.md`) for the catalog of meaningful units.
