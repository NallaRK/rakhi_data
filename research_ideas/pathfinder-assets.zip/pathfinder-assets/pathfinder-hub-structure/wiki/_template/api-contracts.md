---
last_optimized: <ISO date>
optimized_by: pathfinder-skill
verified_accurate: []
unverified: []
inaccurate_flagged: []
---

# API Contracts — <Repo Name>

## For frontend repos: APIs this MFE CONSUMES

### From `<backend-repo-name>`

#### `GET /api/<path>`
- **Called by:** `<useHookName>` in `src/hooks/<useHookName>.ts`
- **Request:** <path params, query params, body if any>
- **Response:** `<DTO type>` (defined in `<path/to/types.ts>`)
- **Errors handled:**
  - 401 → redirect to login
  - 404 → empty state
  - 500 → toast + retry button
- **Stability:** Stable / Beta / Internal

#### `POST /api/<path>`
...

### From `<other-backend-repo-name>`

...

---

## For backend repos: APIs this service EXPOSES

### Resource: `<resource name>` (base path: `/api/<resource>`)

#### `GET /api/<resource>/{id}`
- **Handler:** `<ControllerName>.<methodName>` in `<file path>`
- **Authentication:** Required (JWT)
- **Authorization:** <who can call this>
- **Request:** path params: `id` (UUID)
- **Response:** `<DtoClassName>` (in `<file path>`)
  ```json
  {
    "id": "string (UUID)",
    "field1": "string",
    "field2": 123
  }
  ```
- **Status codes:**
  - 200 — found
  - 403 — caller not authorized for this resource
  - 404 — not found
- **Consumed by:** `<frontend-repo>` (`<hook name>`)
- **Stability:** Stable

#### `POST /api/<resource>`
...

### Internal endpoints (not for external consumers)

#### `POST /api/internal/<path>`
...

---

## Versioning

<Current strategy: unversioned / `/v1/` prefix / header-based>

## Breaking change protocol

<How the team handles breaking changes to consumed/exposed APIs.>

## See also

- `pathfinder-hub/cross-repo/api-contracts-index.md` — index across all repos
- `pathfinder-hub/cross-repo/dependency-map.md` — full consumer graph
