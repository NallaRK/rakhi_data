---
last_optimized: <ISO date>
optimized_by: pathfinder-skill
verified_accurate: []
unverified: []
inaccurate_flagged: []
---

# Data Model — <Repo Name>

For backend repos only. Frontend repos don't need this file.

## Database

- Type: MongoDB
- Connection: configured in `<file path>`
- Multi-tenancy: <if applicable, how tenants are isolated>

## Collections

### `<collection_name>`

- **Document class:** `<DocumentClassName>` in `<file path>`
- **Owning service:** `<ServiceName>`
- **Purpose:** <one sentence — business meaning>

**Schema:**
```
{
  _id: ObjectId,
  clientId: String,        // FK-like reference to client-service
  status: Enum("DRAFT", "SUBMITTED", "APPROVED", "REJECTED"),
  submittedAt: Instant,
  // ...
}
```

**Indexes:**
- `_id_` (default)
- `clientId_1_submittedAt_-1` — supports "recent submissions per client" query
- `status_1` — supports admin filter

**Common query patterns:**
- Find by client + date: uses `clientId_1_submittedAt_-1`
- Find by status (admin dashboards): uses `status_1`

**Lifecycle:**
- Created when: <event>
- Modified when: <event>
- Deleted when: <if ever — many collections are append-only with soft delete via status>

### `<collection_name>`
...

## Cross-collection relationships

| Collection | References | Cardinality |
|---|---|---|
| `kyc_submissions` | `clients._id` (in client-service) | many submissions → one client |

These are not enforced at the DB layer (MongoDB). Services check consistency at write time.

## Migration history

- <Date> — <migration name> — <what changed and why>
- <Date> — ...

## Anti-patterns to avoid

- <e.g., do NOT add new indexes without measuring query performance — index bloat is a known issue>
- <e.g., do NOT query without `clientId` filter from non-admin endpoints (security boundary)>
