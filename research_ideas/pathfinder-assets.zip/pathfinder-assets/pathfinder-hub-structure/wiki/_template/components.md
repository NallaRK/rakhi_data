---
last_optimized: <ISO date>
optimized_by: pathfinder-skill
verified_accurate: []
unverified: []
inaccurate_flagged: []
---

# Components — <Repo Name>

This is the catalog of meaningful components in this MFE. NOT every file — only those that other engineers need to know exist.

For backend repos, see `services.md` instead.

## Container components

These manage state and orchestrate child components.

### `<ComponentName>`
- **Path:** `src/components/<ComponentName>.tsx`
- **Purpose:** <one sentence>
- **Mounted at:** <route or parent component>
- **Reads:** <queries, hooks, Redux slices>
- **Writes:** <mutations, Redux actions>
- **Uses (design system):** `<Button>`, `<Modal>`, `<FormField>`
- **Used by:** <if this is itself imported elsewhere>

### `<ComponentName>`
...

## Presentational components

These take props and render. No data fetching.

### `<ComponentName>`
- **Path:** `src/components/<ComponentName>.tsx`
- **Purpose:** <one sentence>
- **Props:** <key props>
- **Uses (design system):** `<List>`, `<Text>`

## Hooks (custom)

### `<useHookName>`
- **Path:** `src/hooks/<useHookName>.ts`
- **Purpose:** <one sentence>
- **API endpoints called:** <list>
- **Returns:** `{ <shape> }`
- **Used by:** `<ComponentName>`

## Patterns to follow when adding new components

- New container components → follow `<existing container>` pattern
- New presentational components → follow `<existing presentational>` pattern
- New hooks → follow `<existing hook>` pattern (React Query under the hood)

## Anti-patterns to avoid

- <Anti-pattern 1 the team has caught in past PRs>
- <Anti-pattern 2>

## Component → API mapping

See `pathfinder-hub/cross-repo/api-contracts-index.md` for the canonical map of which component calls which endpoint.
