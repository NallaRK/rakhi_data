#!/usr/bin/env bash
#
# sync-manifests.sh
#
# Stage 1b helper: copy authoritative manifests from pathfinder-hub into a
# consumer repo. Useful for local testing before running the GHA.
#
# Usage:
#   ./sync-manifests.sh <repo-name> <consumer-repo-path>
#
# Example:
#   ./sync-manifests.sh mfe-kyc ~/code/mfe-kyc
#
# This script does what `workflows/sync-to-repos.yml` does automatically,
# but locally — useful for debugging or one-off syncs.

set -euo pipefail

if [ "$#" -ne 2 ]; then
  echo "Usage: $0 <repo-name> <consumer-repo-path>" >&2
  echo "" >&2
  echo "Example: $0 mfe-kyc ~/code/mfe-kyc" >&2
  exit 1
fi

REPO_NAME="$1"
CONSUMER_PATH="$2"

# Resolve hub root from script location: scripts/sync-manifests.sh
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HUB_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

MANIFEST_SRC="$HUB_ROOT/manifests/$REPO_NAME.json"
MANIFEST_DEST="$CONSUMER_PATH/.github/architecture-manifest.json"

if [ ! -f "$MANIFEST_SRC" ]; then
  echo "ERROR: Manifest not found: $MANIFEST_SRC" >&2
  echo "" >&2
  echo "Available manifests:" >&2
  ls "$HUB_ROOT/manifests/" 2>/dev/null || echo "  (none)"
  exit 1
fi

if [ ! -d "$CONSUMER_PATH" ]; then
  echo "ERROR: Consumer repo path does not exist: $CONSUMER_PATH" >&2
  exit 1
fi

if [ ! -d "$CONSUMER_PATH/.git" ]; then
  echo "WARN: $CONSUMER_PATH does not appear to be a git repo" >&2
fi

mkdir -p "$CONSUMER_PATH/.github"

# Diff before overwriting so the user can see the change
if [ -f "$MANIFEST_DEST" ]; then
  if diff -q "$MANIFEST_DEST" "$MANIFEST_SRC" > /dev/null; then
    echo "✓ $REPO_NAME manifest already up-to-date in $CONSUMER_PATH"
    exit 0
  fi
  echo "Changes that will be applied:"
  diff -u "$MANIFEST_DEST" "$MANIFEST_SRC" || true
  echo ""
  read -p "Apply? [y/N] " confirm
  if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
    echo "Aborted."
    exit 0
  fi
fi

cp "$MANIFEST_SRC" "$MANIFEST_DEST"
echo "✓ Copied $MANIFEST_SRC → $MANIFEST_DEST"
echo ""
echo "Next steps:"
echo "  cd $CONSUMER_PATH"
echo "  git checkout -b pathfinder-hub-sync/manifest-update"
echo "  git add .github/architecture-manifest.json"
echo "  git commit -m 'chore(pathfinder): sync architecture-manifest.json from hub'"
echo "  # Open a PR against develop"
