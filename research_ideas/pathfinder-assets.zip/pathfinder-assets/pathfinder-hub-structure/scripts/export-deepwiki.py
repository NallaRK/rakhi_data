#!/usr/bin/env python3
"""
Stage 1a helper: convert pasted DeepWiki text exports into docs/wiki/ markdown files.

The Devin DeepWiki feature exports as plain text (sometimes with section headers,
sometimes as one big blob). This script:
  1. Takes a DeepWiki text export from stdin or a file
  2. Splits it into sections by H2 headings (## Title)
  3. Maps section titles to expected wiki filenames (overview, architecture, etc.)
  4. Writes one file per section into docs/wiki/

After running this, the developer should:
  1. Review each file
  2. Run @deepwiki-optimizer skill on each (or prompts/03-optimize-deepwiki-content.md)
  3. Commit to docs/wiki/

Usage:
    python export-deepwiki.py < deepwiki-export.txt
    python export-deepwiki.py deepwiki-export.txt
    python export-deepwiki.py deepwiki-export.txt --out docs/wiki

This is a Stage 1a-only tool. In Stage 1b, wikis are sourced from pathfinder-hub.
"""

import argparse
import re
import sys
from pathlib import Path


# Map common DeepWiki section heading patterns to canonical filenames
SECTION_TO_FILENAME = {
    # Overview-ish
    "overview": "overview.md",
    "summary": "overview.md",
    "introduction": "overview.md",
    "about": "overview.md",
    # Architecture-ish
    "architecture": "architecture.md",
    "structure": "architecture.md",
    "design": "architecture.md",
    "directory structure": "architecture.md",
    # Components / services
    "components": "components.md",
    "services": "services.md",
    "modules": "components.md",
    # API
    "api": "api-contracts.md",
    "api contracts": "api-contracts.md",
    "endpoints": "api-contracts.md",
    "rest api": "api-contracts.md",
    # Data
    "data model": "data-model.md",
    "database": "data-model.md",
    "schema": "data-model.md",
    "collections": "data-model.md",
    # Glossary
    "glossary": "domain-glossary.md",
    "terminology": "domain-glossary.md",
    "domain glossary": "domain-glossary.md",
}


def match_section_to_filename(heading_text: str) -> str:
    """Given an H2 heading like '## Architecture Overview', return 'architecture.md'."""
    normalized = heading_text.strip().lower()
    normalized = re.sub(r"[^a-z0-9 ]", "", normalized)

    # Exact match first
    if normalized in SECTION_TO_FILENAME:
        return SECTION_TO_FILENAME[normalized]

    # Substring match: pick the longest matching key (most specific)
    matches = [
        (key, value)
        for key, value in SECTION_TO_FILENAME.items()
        if key in normalized
    ]
    if matches:
        matches.sort(key=lambda x: len(x[0]), reverse=True)
        return matches[0][1]

    # Fallback: turn heading into a slug filename
    slug = re.sub(r"[^a-z0-9]+", "-", normalized).strip("-")
    return f"{slug or 'untitled'}.md"


def split_into_sections(text: str) -> dict[str, str]:
    """Split markdown text by ## headings into a dict of {heading: body}."""
    sections: dict[str, str] = {}
    parts = re.split(r"^(##\s+.+)$", text, flags=re.MULTILINE)

    # Handle content before the first ##
    intro = parts[0].strip()
    if intro:
        sections["__intro__"] = intro

    # Walk pairs of (heading, body)
    for i in range(1, len(parts), 2):
        heading = parts[i].strip().lstrip("# ").strip()
        body = parts[i + 1] if i + 1 < len(parts) else ""
        sections[heading] = (parts[i] + body).strip()

    return sections


FRONT_MATTER_TEMPLATE = """---
last_optimized: PENDING — run @deepwiki-optimizer skill
optimized_by: export-deepwiki.py (raw paste)
verified_accurate: []
unverified: [all sections — review before merging]
inaccurate_flagged: []
---

"""


def write_section(out_dir: Path, filename: str, content: str) -> Path:
    """Write a section to out_dir/filename, with front matter prepended."""
    out_path = out_dir / filename
    out_path.parent.mkdir(parents=True, exist_ok=True)

    full_content = FRONT_MATTER_TEMPLATE + content
    out_path.write_text(full_content, encoding="utf-8")
    return out_path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "input",
        nargs="?",
        default=None,
        help="Path to DeepWiki text export. Reads stdin if omitted.",
    )
    parser.add_argument(
        "--out",
        default="docs/wiki",
        help="Output directory (default: docs/wiki)",
    )
    args = parser.parse_args()

    # Read input
    if args.input:
        text = Path(args.input).read_text(encoding="utf-8")
    else:
        text = sys.stdin.read()

    if not text.strip():
        print("ERROR: No input provided", file=sys.stderr)
        sys.exit(1)

    out_dir = Path(args.out)

    # Split and write
    sections = split_into_sections(text)

    if "__intro__" in sections:
        # Intro paragraph (no heading) goes into overview.md
        intro = sections.pop("__intro__")
        existing = sections.get("Overview") or sections.get("overview")
        if existing:
            sections["Overview"] = intro + "\n\n" + existing
        else:
            sections["Overview"] = "## Overview\n\n" + intro

    written_files: list[Path] = []
    for heading, body in sections.items():
        filename = match_section_to_filename(heading)
        path = write_section(out_dir, filename, body)
        written_files.append(path)
        print(f"  wrote {path}")

    print(f"\n✓ Wrote {len(written_files)} files to {out_dir}/")
    print("\nNext steps:")
    print(f"  1. Review each file in {out_dir}/")
    print("  2. Run @deepwiki-optimizer skill in Copilot Chat on each file")
    print("  3. Resolve all UNVERIFIED markers")
    print("  4. Update the front-matter `last_optimized` field")
    print("  5. Commit to the repo")


if __name__ == "__main__":
    main()
