# Pathfinder Assets

This package contains every asset referenced by `pathfinder-implementation-plan.md`. Use this as the source-of-truth scaffold for building Pathfinder in your environment.

## What's in here

```
pathfinder-assets/
├── README.md                          # this file
│
├── agents/                            # 6 VSCode Copilot custom agents (.agent.md files)
│   ├── orchestrator.agent.md          #   Pattern B lead — branches based on story content
│   ├── story-analyzer.agent.md        #   reads JIRA, queries hub, identifies repos
│   ├── design-analyzer.agent.md       #   handles Figma PNG/JPG attachments via vision
│   ├── spec-writer.agent.md           #   wraps Spec Kit for greenfield features only
│   ├── implementation-planner.agent.md #  produces ordered file-by-file plan
│   └── code-reviewer.agent.md         #   independent verifier — maker-checker split
│
├── prompts/                           # 6 one-time setup prompts (run once per repo)
│   ├── 01-generate-copilot-instructions.md
│   ├── 02-generate-architecture-manifest.md
│   ├── 03-optimize-deepwiki-content.md
│   ├── 04-build-wiki-from-scratch.md
│   ├── 05-build-cross-repo-docs.md
│   └── 06-figma-design-extraction.md
│
├── skills/                            # 4 reusable Copilot skills (auto-activate by trigger)
│   ├── deepwiki-optimizer.md
│   ├── manifest-generator.md
│   ├── cross-repo-analyzer.md
│   └── design-system-mapper.md
│
├── manifests/                         # 2 schema templates for .github/architecture-manifest.json
│   ├── architecture-manifest-react-mfe.template.json
│   └── architecture-manifest-spring-boot.template.json
│
├── mcp-server/                        # FastMCP server (Python, no Docker)
│   ├── server.py
│   ├── requirements.txt
│   ├── tools/
│   │   ├── __init__.py
│   │   ├── find_repos.py
│   │   ├── get_repo_context.py
│   │   ├── impact_analysis.py
│   │   ├── enhance_story.py
│   │   ├── search_wiki.py
│   │   └── cross_repo_dependencies.py
│   └── README.md
│
├── workflows/                         # 3 GitHub Actions workflows
│   ├── sync-to-repos.yml              #   syncs manifests from hub → consumers
│   ├── quarterly-refresh.yml          #   freshness reports every 3 months
│   └── deepwiki-export-helper.yml     #   Stage 1a PR comment helper
│
└── pathfinder-hub-structure/          # scaffold for the future pathfinder-hub repo (Stage 1b)
    ├── README.md
    ├── wiki/_template/                #   skeleton wikis (overview, architecture, etc.)
    ├── cross-repo/_templates/         #   skeleton cross-repo files
    ├── manifests/                     #   empty — populated in Stage 1b
    └── scripts/
        ├── export-deepwiki.py         #   Stage 1a: paste DeepWiki text → docs/wiki/
        └── sync-manifests.sh          #   Stage 1b: local sync (alternative to GHA)
```

## How to use this package

This is reference material. Do NOT just dump it into a repo. The markdown playbook (`pathfinder-implementation-plan.md`, delivered alongside this zip) describes when and how to use each piece across Stages 1a (Weeks 1–2) and 1b (Weeks 3–6).

Quick map of which assets matter for which stage:

| Stage | Use these assets |
|---|---|
| 1a Week 1 | `prompts/01`, `prompts/02`, `prompts/03`, `agents/*`, `pathfinder-hub-structure/scripts/export-deepwiki.py` |
| 1a Week 2 | All Week 1 + `workflows/deepwiki-export-helper.yml` |
| 1b Weeks 3–4 | `pathfinder-hub-structure/` (copy to new repo), `mcp-server/`, `manifests/`, `prompts/05` |
| 1b Weeks 5–6 | `workflows/sync-to-repos.yml`, `workflows/quarterly-refresh.yml`, `skills/*` |

## Critical conventions

- **Open-source only.** Every dependency in `mcp-server/requirements.txt` is MIT/BSD/Apache licensed. Verify before adding more.
- **No Docker.** Use `python`, `pip`, `npm`, `java -jar` only. Stage 1b MCP server is deployable via `systemd` on a Linux host.
- **No Yarn.** `npm ci` / `npx` everywhere.
- **Hub is authoritative.** Per-repo `.github/architecture-manifest.json` files are derived copies. Never edit them locally — edit `pathfinder-hub/manifests/{repo}.json` and let the sync workflow update consumers.

## Compatibility

Tested mental model against:
- VSCode Copilot Enterprise (custom agents GA as of VS Code 1.109 / Feb 2026)
- Pattern B (Subagent Delegation) via `agents:` frontmatter allowlist
- Sub-agents inherit parent model (known constraint, GitHub issue #310138)
- Vision required for `design-analyzer` agent (Claude Opus 4.6/4.7 or GPT-5.2)

## Where to start

Read `pathfinder-implementation-plan.md` (delivered alongside this zip). It walks through Stage 1a and Stage 1b chronologically and references each asset by path.
