---
name: design-system-mapper
description: 'Maps UI elements (from Figma PNGs, descriptions, or sketches) to existing components in @your-org/design-system. Reads node_modules/@your-org/design-system/dist/*.d.ts and __examples__/ to find exact prop signatures and usage patterns.'
tools: ['search', 'read', 'web']
trigger: 'tasks involving design system component selection OR Figma design analysis'
---

# Design System Mapper Skill

## When this skill activates

Apply this skill whenever a developer is:
- Implementing a design from a JIRA Figma attachment
- Asking "which design system component should I use for X?"
- Reviewing code that uses (or should use) design system components
- Working inside the `@design-analyzer` agent

## Skill behavior

For each UI element to map:

1. **Read the design system surface** via `@workspace`:
   - `node_modules/@your-org/design-system/dist/index.d.ts` — exports and prop signatures
   - `node_modules/@your-org/design-system/dist/*.d.ts` — per-component type definitions
   - `node_modules/@your-org/design-system/__examples__/` — usage patterns
   - `node_modules/@your-org/design-system/stories/` — Storybook source (if present)

2. **Match the UI element to a component:**
   - By name (annotated): "Modal-Large" → `<Modal size="large">`
   - By visual pattern: similar shape/structure to a known component
   - By usage context: form fields use `<FormField>`, action buttons use `<Button variant="primary">`

3. **Derive props with confidence labels:**
   - **Annotated:** value comes from the design (high confidence)
   - **Inferred:** your best guess from visual similarity (medium/low confidence)
   - **Default:** value not specified; using design system default

4. **Cite the pattern file:**
   - For each match, reference the relevant `__examples__/<Component>.tsx` or `stories/<Component>.stories.tsx`
   - The implementing developer should follow this pattern, not write from scratch

## Skill rules

- **The design system is the constraint, not a suggestion.** If a design element doesn't match an existing component, do NOT propose custom CSS. Flag it as a design-system gap requiring discussion.
- **`.d.ts` files are ground truth for props.** Don't infer prop names from visual context — read the TypeScript definition.
- **Predefined theme tokens only.** The organization has predefined spacing, color, and font tokens. Never invent new ones. Reference existing tokens by name.
- **Annotated values always beat inferred values.** When the design explicitly says "size=large", don't second-guess based on what "looks medium."

## Output format

For each mapped element:

```
### Element: <name>
- **Component:** `<ComponentName>` from `@your-org/design-system`
- **Path:** `node_modules/@your-org/design-system/dist/<ComponentName>.d.ts`
- **Pattern:** `node_modules/@your-org/design-system/__examples__/<ExampleFile>.tsx`
- **Props:**
  - `variant="primary"` (annotated)
  - `size="medium"` (inferred — default)
  - `disabled={false}` (default)
- **Confidence:** High
```

## Failure modes to avoid

- **Hallucinating components.** Don't claim `<Modal>` exists if you haven't verified in `dist/index.d.ts`.
- **Hallucinating props.** A component's prop set is exact. Use `.d.ts` definitions.
- **Treating "looks like" as "is."** Visual similarity is a signal, not proof. Cite annotations when available.
- **Suggesting custom implementations.** Your job is to map to existing components. If nothing matches, escalate — do not write custom code.
- **Inventing theme tokens.** "theme.spacing.huge" doesn't exist unless you verify it. Read the design system's token exports.

## What this skill is NOT

- A code generator. It identifies components to use; it doesn't write the JSX.
- A design tool. It doesn't critique the design or suggest changes.
- A replacement for the `@design-analyzer` agent. The agent handles the full workflow (read PNGs, map components, flag uncertainties); this skill is the component-mapping piece.

## See also
- `agents/design-analyzer.agent.md` — the agent that uses this skill
- `prompts/06-figma-design-extraction.md` — for standalone usage without the agent
