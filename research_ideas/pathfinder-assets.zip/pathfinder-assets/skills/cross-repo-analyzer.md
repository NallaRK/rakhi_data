---
name: cross-repo-analyzer
description: 'Builds and maintains cross-repo intelligence files (dependency-map, shared-components-registry, api-contracts-index, domain-glossary) by aggregating data from pathfinder-hub/manifests/ and pathfinder-hub/wiki/. Use when files in pathfinder-hub/cross-repo/ need regeneration.'
tools: ['search', 'read', 'edit', 'web']
trigger: 'files matching pathfinder-hub/cross-repo/**/*.md'
---

# Cross-Repo Analyzer Skill

## When this skill activates

Apply this skill whenever a developer is:
- Generating or refreshing files in `pathfinder-hub/cross-repo/`
- Investigating cross-repo dependencies for a feature
- Running the quarterly refresh workflow

## Skill behavior

Four output files, each with distinct generation logic. Follow `prompts/05-build-cross-repo-docs.md` for the canonical workflow.

### dependency-map.md
- Source: all `pathfinder-hub/manifests/*.json`
- Aggregate: `relatedRepos`, `apiEndpoints.consumedBy`, `sharedComponents`
- Output: Mermaid graph + tabular dependency view + reverse-dependency listing + deployment-order implications

### shared-components-registry.md
- Source: `sharedComponents[*]` across all MFE manifests
- Aggregate: usage count per component per MFE
- Output: usage matrix + high-risk components (3+ MFE consumers) + orphaned components (1 or 0 consumers)

### api-contracts-index.md
- Source: `apiEndpoints[*]` from backend manifests (authoritative) cross-referenced with frontend manifests (consumers)
- Output: endpoints by service + orphaned endpoints (no consumer) + multi-consumer endpoints (high-change-risk)
- Flag mismatches: frontend claims to consume X, no backend exposes X

### domain-glossary.md
- Source: `pathfinder-hub/wiki/{repo}/domain-glossary.md` from each repo
- Aggregate: de-duplicate terms, surface conflicting definitions
- Output: alphabetized PO-facing glossary

## Skill rules

- **Manifests are the source of truth** for dependencies, APIs, and shared components. Wikis are the source of truth for domain language.
- **Cross-check before asserting.** If repo A claims to call API X from repo B, verify repo B exposes API X. If not, flag.
- **Surface conflicts; don't resolve them.** If two repos define "client" differently, show both definitions and flag the conflict. Resolution is a team discussion, not an AI judgment.
- **Update timestamps.** Every regeneration updates the `Last updated:` header.

## Failure modes to avoid

- **Inventing dependencies.** Only document what's in the manifests. If you think a dependency "must exist," verify and add to the manifest first.
- **Over-interpreting orphans.** An "orphaned" endpoint might be used by an external system, a cron job, or a repo not in the pilot. Flag as orphan-in-pilot, not orphan-absolutely.
- **Generating outdated content.** If manifests are stale, the cross-repo output will be stale. Always confirm manifest freshness (check `lastIndexed` field) before regenerating.

## Quarterly refresh integration

This skill is invoked by `workflows/quarterly-refresh.yml`. The GHA:
1. Re-runs the manifest-generator skill on each pilot repo
2. Re-runs this skill on `pathfinder-hub/cross-repo/`
3. Opens a PR with the diff for human review

Never auto-merge the PR. Cross-repo content is too consequential to merge without a human reading the diff.

## See also
- `prompts/05-build-cross-repo-docs.md` — the canonical prompts
- `workflows/quarterly-refresh.yml` — the GHA that runs this skill on schedule
