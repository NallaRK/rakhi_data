---
name: manifest-generator
description: 'Generates or updates .github/architecture-manifest.json from the current repo code. Use when setting up Pathfinder for a new repo, or after a significant refactor that changes the repo structure.'
tools: ['search', 'read', 'edit']
trigger: 'files matching .github/architecture-manifest.json OR pathfinder-hub/manifests/*.json'
---

# Manifest Generator Skill

## When this skill activates

Apply this skill whenever a developer is:
- Setting up Pathfinder for a new repo (creating `.github/architecture-manifest.json` for the first time)
- Updating an existing manifest after a refactor
- Generating an authoritative manifest in `pathfinder-hub/manifests/{repo-name}.json`

## Skill behavior

Generate or update the manifest following the schema in `prompts/02-generate-architecture-manifest.md`. The schema differs by repo type:

- **React MFE (TypeScript + Redux Toolkit + React Query):** components, hooks, apiEndpoints, sharedComponents, relatedRepos
- **Java Spring Boot (Java 17 + Spring Data MongoDB):** controllers, services, mongoCollections, apiEndpoints, relatedRepos

## Skill rules

- **Read code before writing manifest.** Every entry must be traceable to a source file via `@workspace` or `search/codebase`.
- **Never invent endpoints.** Common failure: inferring "there must be a DELETE endpoint" because GET and POST exist. Verify.
- **`describes` fields are ONE short sentence.** Max 100 characters each. Long descriptions belong in the wiki, not the manifest.
- **Omit unknown fields.** If you can't determine a field, leave it out rather than guess.
- **Order fields consistently.** Use the schema's field order for deterministic diffs.

## Schema validation

After generation, verify the output is valid JSON:
- All strings properly quoted
- No trailing commas
- File paths use forward slashes even on Windows

## Diff awareness

When updating an existing manifest:
- Show the developer a clear diff of added/removed/changed entries
- Highlight removed entries — these indicate code that was deleted (potential cross-repo impact)
- Highlight added entries — these indicate new surface area

## Failure modes to avoid

- **Manifests that drift from code.** If you flag uncertainty about a field, prefer omission over guessing.
- **Bloated manifests.** Don't list every file in the repo. Only meaningful architectural surface (components used elsewhere, public APIs, etc.).
- **Inconsistent `relatedRepos`.** Cross-check: if repo A says it consumes API from repo B, repo B's manifest should show repo A in `apiEndpoints[*].consumedBy`.

## See also
- `prompts/02-generate-architecture-manifest.md` — the canonical prompt
- `manifests/architecture-manifest-react-mfe.template.json` — schema template
- `manifests/architecture-manifest-spring-boot.template.json` — schema template
