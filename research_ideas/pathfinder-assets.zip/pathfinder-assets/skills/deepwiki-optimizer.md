---
name: deepwiki-optimizer
description: 'Optimizes generic DeepWiki-generated content for Pathfinder use. Adds team context, verifies accuracy against current code, adds cross-repo references, strips boilerplate. Invoke when working with files in docs/wiki/ or pathfinder-hub/wiki/.'
tools: ['search', 'read', 'edit', 'web']
trigger: 'files matching docs/wiki/*.md OR pathfinder-hub/wiki/**/*.md'
---

# DeepWiki Optimizer Skill

## When this skill activates

Apply this skill whenever a developer is:
- Editing a file in `docs/wiki/` after pasting DeepWiki content
- Working with content in `pathfinder-hub/wiki/{repo-name}/`
- Asked to "optimize" or "tweak" auto-generated documentation

## Skill behavior

When activated, apply the optimization passes from `prompts/03-optimize-deepwiki-content.md`:

1. **Verify accuracy** — cross-check claims against current code via `@workspace`. Flag `<!-- UNVERIFIED: ... -->` or `<!-- INACCURATE: ... -->`.
2. **Add team context** — short "Team context" sub-sections explaining intent, anti-patterns, and internal terminology.
3. **Add cross-repo references** — link to other repos that consume or depend on this code.
4. **Strip generic boilerplate** — remove generic framework explanations, setup tutorials, and auto-generated lists.
5. **Update front matter** — add `last_optimized` timestamp and verification status.

## Skill rules

- **Never overwrite without showing diff first.** Always present the optimization side-by-side with the original.
- **Empty sections beat invented ones.** If you cannot answer "why this pattern?" from code/history, leave the sub-section empty rather than guess.
- **Do not modify code** while optimizing docs. If you find a bug, file a JIRA ticket separately.
- **Read 5+ source files before claiming a pattern.** Patterns are observed across files, not inferred from one example.

## Output format

Always produce output as a unified diff or side-by-side comparison so the developer can review before committing. Never write directly to disk without confirmation.

## Failure modes to avoid

- **Hallucinating team intent.** "The team chose X because Y" is only acceptable if Y is in a comment, commit message, or PR description.
- **Marking content as verified without checking.** If you didn't actually run `@workspace` on the cited files, don't claim verification.
- **Generic optimizations.** "Made it clearer" is not optimization. Specific, traceable changes are.

## See also
- `prompts/03-optimize-deepwiki-content.md` — the canonical prompt this skill encapsulates
- `prompts/04-build-wiki-from-scratch.md` — for files where no DeepWiki content exists
