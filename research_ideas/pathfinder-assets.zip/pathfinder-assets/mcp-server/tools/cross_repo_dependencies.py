"""
Tool implementation: cross_repo_dependencies

Return upstream + downstream dependencies for a single repo.
Useful for deployment-order planning and refactoring impact assessment.
"""

import json
from pathlib import Path
from typing import Any


def _load_all_manifests(manifests_dir: Path) -> dict[str, dict]:
    """Load all manifests into memory keyed by repoName."""
    manifests = {}
    for manifest_file in manifests_dir.glob("*.json"):
        try:
            with manifest_file.open() as f:
                data = json.load(f)
            repo_name = data.get("repoName") or manifest_file.stem
            manifests[repo_name] = data
        except json.JSONDecodeError:
            continue
    return manifests


def cross_repo_dependencies_impl(
    repo_name: str, manifests_dir: Path, cross_repo_dir: Path
) -> dict[str, Any]:
    """Main entry point — see server.py docstring for return shape."""

    manifests = _load_all_manifests(manifests_dir)
    target_manifest = manifests.get(repo_name)

    if not target_manifest:
        return {
            "repo": repo_name,
            "not_found": True,
            "available_repos": sorted(manifests.keys()),
        }

    # Upstream = what THIS repo depends on
    upstream: list[dict] = []
    for related in target_manifest.get("relatedRepos", []):
        rel_type = related.get("relationship", "")
        if rel_type in (
            "consumes-api",
            "depends-on-utils",
            "shares-design-system",
            "depends-on-shared-lib",
        ):
            upstream.append(
                {
                    "repo": related.get("repo", ""),
                    "type": rel_type,
                }
            )

    # Downstream = what depends on THIS repo
    # Scan all other manifests for references back to this repo
    downstream: list[dict] = []
    for other_repo_name, other_manifest in manifests.items():
        if other_repo_name == repo_name:
            continue
        for related in other_manifest.get("relatedRepos", []):
            if related.get("repo") == repo_name:
                rel_type = related.get("relationship", "")
                # Map the other repo's perspective back to ours
                downstream_entry = {
                    "repo": other_repo_name,
                    "type": rel_type,
                }
                # If they consume our API, list the specific endpoints
                if rel_type == "consumes-api":
                    consumed_endpoints = []
                    our_endpoints = {
                        e.get("path"): e
                        for e in target_manifest.get("apiEndpoints", [])
                    }
                    for their_endpoint in other_manifest.get("apiEndpoints", []):
                        if their_endpoint.get("consumesService") == repo_name:
                            consumed_endpoints.append(
                                f"{their_endpoint.get('method', 'GET')} {their_endpoint.get('path', '')}"
                            )
                    if consumed_endpoints:
                        downstream_entry["endpoints"] = consumed_endpoints
                downstream.append(downstream_entry)

    # Deployment order implications
    deployment_notes: list[str] = []
    api_consumers_downstream = [d for d in downstream if d.get("type") == "consumes-api"]
    if api_consumers_downstream:
        deployment_notes.append(
            f"When changing this repo's API, deploy this service FIRST, "
            f"then the {len(api_consumers_downstream)} consumer(s)."
        )

    design_system_consumers = [
        d
        for d in downstream
        if d.get("type") == "shares-design-system"
        or "design-system" in d.get("type", "")
    ]
    if design_system_consumers:
        deployment_notes.append(
            f"This repo is consumed as a design system / shared library by "
            f"{len(design_system_consumers)} repo(s). "
            f"Major version bumps require coordinated rollout."
        )

    if not deployment_notes:
        deployment_notes.append(
            "No downstream consumers identified. "
            "Changes to this repo should not require coordinated deployment."
        )

    return {
        "repo": repo_name,
        "upstream": upstream,
        "downstream": downstream,
        "deployment_order_implications": " ".join(deployment_notes),
        "upstream_count": len(upstream),
        "downstream_count": len(downstream),
    }
