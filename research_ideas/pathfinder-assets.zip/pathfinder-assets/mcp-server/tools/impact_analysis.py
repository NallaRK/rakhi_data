"""
Tool implementation: impact_analysis

Given a symbol name or file path, return all repos that reference it.

Phase 1 implementation: text-based search across manifests and wiki.
Phase 3 (future): replace with ArcadeDB graph query using SCIP indexes.
"""

import json
from pathlib import Path
from typing import Any


def impact_analysis_impl(
    symbol_or_file: str, manifests_dir: Path, cross_repo_dir: Path
) -> dict[str, Any]:
    """Main entry point — see server.py docstring for return shape."""

    query_lower = symbol_or_file.lower()
    direct_references: list[dict] = []
    transitive_impact: set[str] = set()

    # Search across all manifests
    for manifest_file in manifests_dir.glob("*.json"):
        try:
            with manifest_file.open() as f:
                manifest = json.load(f)
        except json.JSONDecodeError:
            continue

        repo_name = manifest.get("repoName", manifest_file.stem)
        matching_files: list[str] = []

        # Check components
        for comp in manifest.get("components", []):
            if (
                query_lower in comp.get("name", "").lower()
                or query_lower in " ".join(comp.get("uses", [])).lower()
            ):
                matching_files.append(comp.get("path", ""))

        # Check hooks
        for hook in manifest.get("hooks", []):
            if query_lower in hook.get("name", "").lower():
                matching_files.append(hook.get("path", ""))

        # Check shared component usage
        for shared in manifest.get("sharedComponents", []):
            if query_lower in shared.get("name", "").lower() or query_lower in shared.get(
                "package", ""
            ).lower():
                matching_files.extend(shared.get("usedIn", []))

        # Check API endpoints
        for endpoint in manifest.get("apiEndpoints", []):
            if query_lower in endpoint.get("path", "").lower():
                # The endpoint is in this repo — also surface direct file if available
                handler = endpoint.get("handler") or endpoint.get("calledBy", [])
                if isinstance(handler, list):
                    matching_files.extend(handler)
                elif handler:
                    matching_files.append(str(handler))

        if matching_files:
            direct_references.append(
                {"repo": repo_name, "files": list(set(matching_files))}
            )

            # Add downstream repos (those that depend on this one) as transitive impact
            for related in manifest.get("relatedRepos", []):
                if related.get("relationship") in (
                    "consumed-by-frontend",
                    "depended-on-by",
                ):
                    transitive_impact.add(related.get("repo", ""))

    # Compute blast radius
    direct_repo_count = len(direct_references)
    direct_file_count = sum(len(r["files"]) for r in direct_references)
    transitive_count = len(transitive_impact - {r["repo"] for r in direct_references})

    blast_radius = (
        f"{direct_repo_count} direct repos, "
        f"{direct_file_count} files, "
        f"{transitive_count} transitive downstream repos"
    )

    return {
        "query": symbol_or_file,
        "direct_references": direct_references,
        "transitive_impact": sorted(
            transitive_impact - {r["repo"] for r in direct_references}
        ),
        "blast_radius": blast_radius,
        "note": (
            "Phase 1 impact analysis uses text search on manifests. "
            "For symbol-precision impact (e.g., catching all transitive callers), "
            "see Phase 3 roadmap for SCIP + ArcadeDB graph queries."
        ),
    }
