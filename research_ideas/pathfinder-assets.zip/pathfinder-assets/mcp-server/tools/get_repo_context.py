"""
Tool implementation: get_repo_context

Return the full manifest + wiki content for a single repo.
"""

import json
from pathlib import Path
from typing import Any


def get_repo_context_impl(
    repo_name: str, manifests_dir: Path, wiki_dir: Path
) -> dict[str, Any]:
    """Main entry point — see server.py docstring for return shape."""

    # Load manifest
    manifest_path = manifests_dir / f"{repo_name}.json"
    manifest: dict | None = None
    if manifest_path.is_file():
        try:
            with manifest_path.open() as f:
                manifest = json.load(f)
        except json.JSONDecodeError:
            manifest = None

    # Load wiki files
    repo_wiki_dir = wiki_dir / repo_name
    wiki: dict[str, str] = {}
    if repo_wiki_dir.is_dir():
        for md_file in repo_wiki_dir.glob("*.md"):
            try:
                wiki[md_file.name] = md_file.read_text(encoding="utf-8")
            except OSError as e:
                wiki[md_file.name] = f"<!-- ERROR reading file: {e} -->"

    not_found = manifest is None and not wiki

    return {
        "repo": repo_name,
        "manifest": manifest,
        "wiki": wiki,
        "not_found": not_found,
        "manifest_found": manifest is not None,
        "wiki_files_found": len(wiki),
    }
