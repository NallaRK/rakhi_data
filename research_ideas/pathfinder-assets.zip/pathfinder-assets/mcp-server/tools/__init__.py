"""
Pathfinder Hub MCP server tool implementations.

Each module here implements one tool exposed by server.py.
Keeping tools in separate modules makes them independently testable.
"""
