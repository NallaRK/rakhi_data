"""
Tool implementation: search_wiki

Full-text search across all wiki content in pathfinder-hub/wiki/.
Uses BM25 ranking (no external service required, no vector DB).
"""

from pathlib import Path
from typing import Any
import re

try:
    from rank_bm25 import BM25Okapi
    HAS_BM25 = True
except ImportError:
    HAS_BM25 = False


def _tokenize(text: str) -> list[str]:
    """Simple whitespace + lowercase tokenization. Adequate for code/docs search."""
    return re.findall(r"\w+", text.lower())


def _load_wiki_corpus(wiki_dir: Path) -> tuple[list[str], list[dict]]:
    """
    Walk wiki_dir, load every markdown file, split into sections.
    Returns (corpus_texts, corpus_metadata) where each metadata entry has
    the repo name, file name, and section heading.
    """
    corpus_texts: list[str] = []
    corpus_metadata: list[dict] = []

    for repo_dir in wiki_dir.iterdir():
        if not repo_dir.is_dir() or repo_dir.name.startswith("_"):
            # Skip _template and other underscore-prefixed directories
            continue

        repo_name = repo_dir.name

        for md_file in repo_dir.glob("*.md"):
            try:
                content = md_file.read_text(encoding="utf-8")
            except OSError:
                continue

            # Split on ## headings (section level). Keep the heading with the section.
            sections = re.split(r"^(##\s+.+)$", content, flags=re.MULTILINE)

            # sections looks like: [pre, heading1, body1, heading2, body2, ...]
            # Skip the "pre" (content before the first ##) unless it has body.
            if sections[0].strip():
                # File-level (no section) — index the whole file as one document
                corpus_texts.append(sections[0])
                corpus_metadata.append(
                    {
                        "repo": repo_name,
                        "file": md_file.name,
                        "section": None,
                    }
                )

            for i in range(1, len(sections), 2):
                heading = sections[i].strip()
                body = sections[i + 1] if i + 1 < len(sections) else ""
                combined = f"{heading}\n{body}"
                corpus_texts.append(combined)
                corpus_metadata.append(
                    {
                        "repo": repo_name,
                        "file": md_file.name,
                        "section": heading.lstrip("# ").strip(),
                    }
                )

    return corpus_texts, corpus_metadata


def _make_snippet(text: str, query_terms: list[str], max_len: int = 280) -> str:
    """Extract a short snippet around the first query-term hit."""
    text_lower = text.lower()
    first_hit = -1
    for term in query_terms:
        idx = text_lower.find(term)
        if idx >= 0 and (first_hit < 0 or idx < first_hit):
            first_hit = idx

    if first_hit < 0:
        return text[:max_len] + ("..." if len(text) > max_len else "")

    start = max(0, first_hit - 60)
    end = min(len(text), first_hit + max_len - 60)
    snippet = text[start:end]
    if start > 0:
        snippet = "..." + snippet
    if end < len(text):
        snippet = snippet + "..."
    return snippet


def search_wiki_impl(query: str, wiki_dir: Path, limit: int = 10) -> dict[str, Any]:
    """Main entry point — see server.py docstring for return shape."""

    if not HAS_BM25:
        return {
            "query": query,
            "results": [],
            "error": (
                "rank-bm25 is not installed. "
                "Install with: pip install -r requirements.txt"
            ),
        }

    corpus_texts, corpus_metadata = _load_wiki_corpus(wiki_dir)

    if not corpus_texts:
        return {
            "query": query,
            "results": [],
            "warning": "No wiki content found in pathfinder-hub/wiki/",
        }

    # Build BM25 index on-the-fly. For 6 repos this is fast; for 35 repos
    # consider caching the index. Phase 3 may replace this with ArcadeDB FTS.
    tokenized_corpus = [_tokenize(t) for t in corpus_texts]
    bm25 = BM25Okapi(tokenized_corpus)

    query_tokens = _tokenize(query)
    scores = bm25.get_scores(query_tokens)

    # Pair scores with metadata, sort, take top N
    scored = sorted(
        zip(scores, corpus_texts, corpus_metadata),
        key=lambda x: x[0],
        reverse=True,
    )

    results = []
    for score, text, meta in scored[:limit]:
        if score <= 0:
            continue  # skip docs with no matching terms
        results.append(
            {
                "repo": meta["repo"],
                "file": meta["file"],
                "section": meta["section"],
                "snippet": _make_snippet(text, query_tokens),
                "score": round(float(score), 3),
            }
        )

    return {
        "query": query,
        "results": results,
        "total_documents_searched": len(corpus_texts),
    }
