"""
Tool implementation: find_repos_for_story

Given a JIRA story text, identify which repos are likely affected.

Strategy:
  1. Load all manifests from pathfinder-hub/manifests/*.json
  2. Tokenize the story text
  3. Score each repo by:
     - Component name matches (high signal)
     - API endpoint path matches (high signal)
     - Domain glossary term matches (medium signal)
     - Wiki keyword matches (low signal)
  4. Return ranked list with confidence labels

This is a pragmatic first implementation. Better approaches (vector similarity,
LLM-based scoring) can be added later without changing the tool's interface.
"""

import json
from pathlib import Path
from datetime import datetime, timezone
from typing import Any


def _load_manifests(manifests_dir: Path) -> dict[str, dict]:
    """Load all manifest files into memory. Skip invalid JSON with a warning."""
    manifests = {}
    for manifest_file in manifests_dir.glob("*.json"):
        try:
            with manifest_file.open() as f:
                data = json.load(f)
            repo_name = data.get("repoName") or manifest_file.stem
            manifests[repo_name] = data
        except json.JSONDecodeError as e:
            # Don't crash the whole server because one manifest is malformed.
            # Log and continue.
            print(f"WARN: Skipping malformed manifest {manifest_file}: {e}")
    return manifests


def _score_repo(story_text_lower: str, manifest: dict) -> tuple[float, list[str]]:
    """
    Score a single repo against the story. Returns (score, reasoning_strings).

    Higher score = more likely affected.
    """
    score = 0.0
    reasoning: list[str] = []

    # Component name matches (frontend)
    for comp in manifest.get("components", []):
        name = comp.get("name", "")
        if name and name.lower() in story_text_lower:
            score += 3.0
            reasoning.append(f"Component '{name}' mentioned")

    # Hook name matches
    for hook in manifest.get("hooks", []):
        name = hook.get("name", "")
        if name and name.lower() in story_text_lower:
            score += 2.5
            reasoning.append(f"Hook '{name}' mentioned")

    # Controller / service matches (backend)
    for controller in manifest.get("controllers", []):
        name = controller.get("name", "")
        if name and name.lower() in story_text_lower:
            score += 3.0
            reasoning.append(f"Controller '{name}' mentioned")

    for service in manifest.get("services", []):
        name = service.get("name", "")
        if name and name.lower() in story_text_lower:
            score += 2.5
            reasoning.append(f"Service '{name}' mentioned")

    # API endpoint path matches (both frontend "consumes" and backend "exposes")
    for endpoint in manifest.get("apiEndpoints", []):
        path = endpoint.get("path", "")
        # Match path segments, ignoring the {param} placeholders
        if path:
            for segment in path.split("/"):
                if segment and not segment.startswith("{") and len(segment) > 3:
                    if segment.lower() in story_text_lower:
                        score += 1.5
                        reasoning.append(f"API path '{path}' segment matches")
                        break

    # MongoDB collection matches (backend)
    for coll in manifest.get("mongoCollections", []):
        name = coll.get("name", "")
        if name and name.lower() in story_text_lower:
            score += 2.0
            reasoning.append(f"Collection '{name}' mentioned")

    # Repo name itself
    repo_name = manifest.get("repoName", "")
    if repo_name and repo_name.lower() in story_text_lower:
        score += 4.0
        reasoning.append(f"Repo name '{repo_name}' explicitly mentioned")

    return score, reasoning


def _confidence_label(score: float) -> str:
    """Map raw score to a human-readable confidence label."""
    if score >= 5.0:
        return "high"
    elif score >= 2.0:
        return "medium"
    elif score > 0:
        return "low"
    return "none"


def find_repos_for_story_impl(
    story_text: str, manifests_dir: Path, wiki_dir: Path
) -> dict[str, Any]:
    """Main entry point — see server.py docstring for return shape."""
    manifests = _load_manifests(manifests_dir)

    if not manifests:
        return {
            "matches": [],
            "warning": "No manifests loaded — verify pathfinder-hub/manifests/ contains JSON files",
            "queried_at": datetime.now(timezone.utc).isoformat(),
        }

    story_lower = story_text.lower()

    # Score every repo
    scored: list[tuple[str, float, list[str]]] = []
    for repo_name, manifest in manifests.items():
        score, reasoning = _score_repo(story_lower, manifest)
        if score > 0:
            scored.append((repo_name, score, reasoning))

    # Sort highest score first
    scored.sort(key=lambda x: x[1], reverse=True)

    matches = [
        {
            "repo": repo_name,
            "confidence": _confidence_label(score),
            "raw_score": round(score, 2),
            "reasoning": "; ".join(reasoning),
        }
        for repo_name, score, reasoning in scored
    ]

    return {
        "matches": matches,
        "total_repos_checked": len(manifests),
        "queried_at": datetime.now(timezone.utc).isoformat(),
    }
