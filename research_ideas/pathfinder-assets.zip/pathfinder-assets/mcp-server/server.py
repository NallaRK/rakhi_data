"""
Pathfinder Hub MCP Server

Exposes 6 tools that Pathfinder agents query for cross-repo intelligence:
  - find_repos_for_story      story text       -> list of affected repos with confidence
  - get_repo_context          repo name        -> manifest + wiki content
  - impact_analysis           symbol or file   -> all repos that reference it
  - enhance_story             draft story text -> story with appended technical details
  - search_wiki               query string     -> matching wiki sections across all repos
  - cross_repo_dependencies   repo name        -> upstream + downstream dependency graph

Built on FastMCP (part of official MCP Python SDK). No Docker required.
Runs as a Python process, exposes stdio + streamable HTTP transports.

Setup:
    pip install -r requirements.txt
    python server.py

VSCode config (.vscode/mcp.json in each repo):
    {
      "servers": {
        "pathfinder-hub": {
          "command": "python",
          "args": ["/absolute/path/to/pathfinder-hub/mcp-server/server.py"]
        }
      }
    }

Or for HTTP transport (if running pathfinder-hub MCP on a shared internal server):
    {
      "servers": {
        "pathfinder-hub": {
          "url": "http://pathfinder-hub.internal:8765/mcp"
        }
      }
    }
"""

from mcp.server.fastmcp import FastMCP
from pathlib import Path
from typing import Any
import sys

# Import tool implementations
from tools.find_repos import find_repos_for_story_impl
from tools.get_repo_context import get_repo_context_impl
from tools.impact_analysis import impact_analysis_impl
from tools.enhance_story import enhance_story_impl
from tools.search_wiki import search_wiki_impl
from tools.cross_repo_dependencies import cross_repo_dependencies_impl


# ============================================================================
# Configuration
# ============================================================================

# Resolve pathfinder-hub root from this file's location
# server.py lives at pathfinder-hub/mcp-server/server.py
# So hub root is two levels up
HUB_ROOT = Path(__file__).resolve().parent.parent

MANIFESTS_DIR = HUB_ROOT / "manifests"
WIKI_DIR = HUB_ROOT / "wiki"
CROSS_REPO_DIR = HUB_ROOT / "cross-repo"

# Validate the directory structure on startup. Fail fast if misconfigured.
for required_dir in [MANIFESTS_DIR, WIKI_DIR, CROSS_REPO_DIR]:
    if not required_dir.is_dir():
        print(
            f"ERROR: Required directory not found: {required_dir}\n"
            f"  Expected pathfinder-hub structure:\n"
            f"    pathfinder-hub/\n"
            f"      manifests/\n"
            f"      wiki/\n"
            f"      cross-repo/\n"
            f"      mcp-server/server.py  <- this file\n",
            file=sys.stderr,
        )
        sys.exit(1)


# ============================================================================
# Initialize MCP server
# ============================================================================

mcp = FastMCP(
    "pathfinder-hub",
    instructions=(
        "Pathfinder Hub provides cross-repo intelligence for a 35-repo polyrepo "
        "environment (30 React MFE + 5 Java Spring Boot). Query these tools "
        "before answering questions that involve more than one repo."
    ),
)


# ============================================================================
# Tool definitions
#
# Each tool is a thin wrapper around an implementation in tools/.
# Keeps server.py readable; keeps tool logic testable in isolation.
# ============================================================================


@mcp.tool()
def find_repos_for_story(story_text: str) -> dict[str, Any]:
    """
    Given a JIRA story description, identify which of the polyrepos are
    likely affected. Returns ranked repos with confidence scores and reasoning.

    Args:
        story_text: The JIRA story title + description + acceptance criteria,
                    concatenated as a single string.

    Returns:
        {
          "matches": [
            {"repo": "mfe-kyc", "confidence": "high", "reasoning": "..."},
            {"repo": "kyc-service", "confidence": "high", "reasoning": "..."},
            ...
          ],
          "queried_at": "ISO timestamp"
        }
    """
    return find_repos_for_story_impl(story_text, MANIFESTS_DIR, WIKI_DIR)


@mcp.tool()
def get_repo_context(repo_name: str) -> dict[str, Any]:
    """
    Return the full manifest + wiki content for a single repo. Use this when
    the @story-analyzer agent needs deep context on one specific repo.

    Args:
        repo_name: e.g. "mfe-kyc" or "kyc-service"

    Returns:
        {
          "repo": "mfe-kyc",
          "manifest": { ... full manifest JSON ... },
          "wiki": {
            "overview.md": "...",
            "architecture.md": "...",
            ...
          },
          "not_found": false
        }
    """
    return get_repo_context_impl(repo_name, MANIFESTS_DIR, WIKI_DIR)


@mcp.tool()
def impact_analysis(symbol_or_file: str) -> dict[str, Any]:
    """
    Given a symbol name (component, hook, service, class) or a file path,
    return all repos that reference it. Useful before refactoring or
    deprecating a shared component.

    Args:
        symbol_or_file: e.g. "useAuth" or "@your-org/design-system/Button"
                        or "kyc-service/api/forms/{id}"

    Returns:
        {
          "query": "useAuth",
          "direct_references": [
            {"repo": "mfe-kyc", "files": ["src/components/Login.tsx"]},
            ...
          ],
          "transitive_impact": ["mfe-checkout", "..."],
          "blast_radius": "5 repos, 23 files"
        }
    """
    return impact_analysis_impl(symbol_or_file, MANIFESTS_DIR, CROSS_REPO_DIR)


@mcp.tool()
def enhance_story(draft_story: str) -> dict[str, Any]:
    """
    Take a PO's draft JIRA story (often business-language only) and append a
    "Technical Details" section identifying affected repos, components, APIs,
    and database changes. Intended for use by the JIRA automation rule.

    Args:
        draft_story: PO's original story text

    Returns:
        {
          "original": "...",
          "enhanced": "... + Technical Details section ...",
          "affected_repos": ["mfe-kyc", "kyc-service"],
          "confidence": "high | medium | low",
          "uncertainties": ["empty state not specified", ...]
        }
    """
    return enhance_story_impl(draft_story, MANIFESTS_DIR, WIKI_DIR)


@mcp.tool()
def search_wiki(query: str, limit: int = 10) -> dict[str, Any]:
    """
    Full-text search across all wiki content in pathfinder-hub/wiki/.
    Returns matching sections with repo context.

    Args:
        query: search terms
        limit: max results to return (default 10)

    Returns:
        {
          "query": "KYC form copy",
          "results": [
            {
              "repo": "mfe-kyc",
              "file": "components.md",
              "section": "KycFormContainer",
              "snippet": "... matching content ..."
            },
            ...
          ]
        }
    """
    return search_wiki_impl(query, WIKI_DIR, limit)


@mcp.tool()
def cross_repo_dependencies(repo_name: str) -> dict[str, Any]:
    """
    Return upstream + downstream dependencies for a single repo. Useful for
    deployment-order planning and refactoring impact assessment.

    Args:
        repo_name: e.g. "kyc-service"

    Returns:
        {
          "repo": "kyc-service",
          "upstream": [
            {"repo": "shared-utils", "type": "depends-on-npm-package"}
          ],
          "downstream": [
            {"repo": "mfe-kyc", "type": "consumes-api", "endpoints": [...]},
            {"repo": "mfe-checkout", "type": "consumes-api", "endpoints": [...]}
          ],
          "deployment_order_implications": "..."
        }
    """
    return cross_repo_dependencies_impl(repo_name, MANIFESTS_DIR, CROSS_REPO_DIR)


# ============================================================================
# Entry point
# ============================================================================

if __name__ == "__main__":
    # Default: stdio transport (for VSCode Copilot via .vscode/mcp.json command launcher)
    # For HTTP transport, see README.md
    mcp.run()
