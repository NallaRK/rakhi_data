# Pathfinder Hub MCP Server

This MCP server exposes 6 tools that Pathfinder agents query for cross-repo intelligence across the 35-repo polyrepo (or the 6-repo pilot subset).

## What it does

Sits inside `pathfinder-hub/mcp-server/` and reads:

- `pathfinder-hub/manifests/*.json` — authoritative repo manifests
- `pathfinder-hub/wiki/{repo-name}/*.md` — wiki content per repo
- `pathfinder-hub/cross-repo/*.md` — cross-repo intelligence files

Exposes 6 MCP tools:

| Tool | Purpose |
|---|---|
| `find_repos_for_story` | Identify which repos a JIRA story affects |
| `get_repo_context` | Full manifest + wiki for one repo |
| `impact_analysis` | All repos that reference a symbol or file |
| `enhance_story` | Append technical details to a PO draft story |
| `search_wiki` | Full-text search across all wiki content |
| `cross_repo_dependencies` | Upstream + downstream dependency graph for one repo |

## Setup

### Prerequisites
- Python 3.11+
- pip (no Docker required)

### Install dependencies

```bash
cd pathfinder-hub/mcp-server
pip install -r requirements.txt
```

### Run locally (for development)

```bash
python server.py
```

This starts the MCP server on stdio (the default transport).

### Run as a shared HTTP service (Stage 1b production)

For team-wide access without each developer running their own copy, host the MCP server on an internal Linux server:

1. Clone `pathfinder-hub` to the host
2. Install Python 3.11+ and dependencies
3. Modify `server.py` to use streamable HTTP transport (see the FastMCP docs for `mcp.run(transport="streamable-http", host="0.0.0.0", port=8765)`)
4. Run under `systemd` for restart-on-failure
5. Expose via internal hostname like `http://pathfinder-hub.internal:8765/mcp`

## VSCode configuration

In each consuming repo, create or update `.vscode/mcp.json`:

### Stdio transport (per-developer install)

```json
{
  "servers": {
    "pathfinder-hub": {
      "command": "python",
      "args": ["/absolute/path/to/pathfinder-hub/mcp-server/server.py"]
    }
  }
}
```

### HTTP transport (centralized install)

```json
{
  "servers": {
    "pathfinder-hub": {
      "url": "http://pathfinder-hub.internal:8765/mcp"
    }
  }
}
```

## Testing the server

After starting the server, test from VSCode Copilot:

1. Open a Pathfinder agent (`@story-analyzer` or `@pathfinder-orchestrator`)
2. Ask: "Which repos are affected by this story: <paste JIRA description>"
3. The agent should invoke `find_repos_for_story` via MCP
4. Inspect the tool call in the chat to verify the response shape

## Directory layout this server expects

```
pathfinder-hub/
├── manifests/
│   ├── mfe-kyc.json
│   ├── kyc-service.json
│   └── ...
├── wiki/
│   ├── mfe-kyc/
│   │   ├── overview.md
│   │   ├── architecture.md
│   │   └── ...
│   └── kyc-service/
│       └── ...
├── cross-repo/
│   ├── dependency-map.md
│   ├── shared-components-registry.md
│   ├── api-contracts-index.md
│   └── domain-glossary.md
└── mcp-server/        # <-- this directory
    ├── server.py
    ├── requirements.txt
    ├── tools/
    │   ├── find_repos.py
    │   ├── get_repo_context.py
    │   ├── impact_analysis.py
    │   ├── enhance_story.py
    │   ├── search_wiki.py
    │   └── cross_repo_dependencies.py
    └── README.md
```

The server validates this structure on startup and exits with an error if any required directory is missing.

## Phase 3 evolution

This Phase 1 implementation uses:
- JSON manifests as the source of truth
- Text matching for find/impact/search
- BM25 for full-text search

In Phase 3 (post-pilot, if the pilot succeeds), the server can evolve to:
- SCIP-indexed code graph in ArcadeDB for symbol-precision impact analysis
- Branch-aware queries (main vs release/*)
- Real-time index updates via GitHub Actions

The MCP tool interfaces stay the same. Consumers don't need to change. Only the implementations swap out.

## Troubleshooting

**Server exits with "Required directory not found":**
Verify the directory layout above. The server checks for `manifests/`, `wiki/`, and `cross-repo/` relative to `server.py`'s parent's parent.

**Tools return empty results:**
Verify `pathfinder-hub/manifests/` contains JSON files with the correct schema. See `manifests/architecture-manifest-react-mfe.template.json` and `architecture-manifest-spring-boot.template.json` in the asset package.

**VSCode doesn't detect the server:**
- Restart VSCode after editing `.vscode/mcp.json`
- Check the MCP servers list: command palette → "MCP: List Servers"
- Check the output panel: View → Output → choose "GitHub Copilot" or "MCP" from the dropdown

**HTTP transport returns 404:**
The default path on FastMCP's HTTP transport is `/mcp` (not the root). Make sure the URL in `.vscode/mcp.json` ends with `/mcp`.

## Maintenance

- The server is stateless. It reads files on every tool call.
- Restart required only after server.py or tools/*.py changes
- No restart needed when manifests, wiki, or cross-repo files change
