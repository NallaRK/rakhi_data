# Prompt: Optimize DeepWiki Content for Pathfinder Use

## When to use
Stage 1a, after you've copy-pasted Devin's DeepWiki content into `docs/wiki/` for a repo. DeepWiki is generic by design — this prompt makes it specific to your team's needs, fixes inaccuracies, and adds Pathfinder-specific cross-references.

## Preferred model
**Claude Opus 4.6 (copilot)** — needs careful judgment about what's accurate vs. inferred.

## Why optimize at all
DeepWiki is auto-generated from code structure. It's good at "what exists" and weak at:
- **Why** a pattern is used (intent)
- **When not to use** a pattern (anti-patterns)
- **How it relates** to other repos
- **Team-specific terminology** vs. generic technical terms
- **Accuracy verification** — DeepWiki can hallucinate API endpoints or describe deprecated code as current

This prompt addresses those gaps in one pass per file.

## How to run

For each markdown file in `docs/wiki/`, open the file and run this prompt in Copilot Chat with the file selected (`Ctrl+I` for inline) or referenced (`#file:docs/wiki/architecture.md`).

---

## The prompt

```
I have a DeepWiki-generated file at <file path>. DeepWiki produces accurate but generic documentation from code structure. I need you to optimize it for our team's actual workflow.

Apply the following passes in order:

## Pass 1: Verify accuracy

Read the file. For each claim that references a specific file, class, function, or API endpoint:
- Use @workspace to verify the cited code actually exists
- Flag claims you cannot verify (mark them with `<!-- UNVERIFIED: ... -->`)
- Flag claims that contradict what you find in code (mark them with `<!-- INACCURATE: actual is ... -->`)

Do NOT delete inaccurate content. Mark it, so I can review.

## Pass 2: Add team context

For each major section, add a short "Team context" sub-section that answers:
- **Why this pattern?** (the design decision, if you can infer it from PR history or code comments)
- **When NOT to use it?** (anti-patterns the team has decided against)
- **What's it called internally?** (if the team has a nickname for this pattern, find it in comments or commit messages)

If you cannot answer from the code/history, leave the sub-section empty rather than invent. An empty section signals "ask the team" — an invented section spreads misinformation.

## Pass 3: Cross-repo references

For each component, hook, service, or API endpoint mentioned, check if it's consumed by other repos in the org (look for it in `@your-org/*` package imports, or in API calls from other repos).

Add a "Cross-repo usage" section listing:
- Other repos that consume this code
- Repos this code depends on
- Shared design system components used

If `@workspace` can't see other repos, note: "Cross-repo usage: see `pathfinder-hub/cross-repo/dependency-map.md`"

## Pass 4: Strip generic boilerplate

DeepWiki tends to include sections that read like generic tutorials. Strip:
- Generic explanations of well-known frameworks ("React is a UI library...")
- Boilerplate "How to set up the project" sections (these belong in README.md, not wiki)
- Auto-generated lists that don't add insight (e.g., "Files in this repo: ...")

Keep:
- Anything specific to this codebase
- Anything that explains *why*
- Domain-specific terminology

## Pass 5: Add the front matter

At the top of the file, add:

```yaml
---
last_optimized: <today's ISO date>
optimized_by: pathfinder-skill
verified_accurate: [list sections you verified]
unverified: [list sections marked with UNVERIFIED]
inaccurate_flagged: [list sections marked with INACCURATE]
---
```

## Output

Show me the optimized content side-by-side with the original (using clear section markers like `## ORIGINAL` and `## OPTIMIZED`) so I can review before committing.
```

---

## After running

1. **Read every UNVERIFIED and INACCURATE flag.** These are the highest-value findings — DeepWiki got something wrong, and you've caught it.
2. **Fix accuracy issues manually** rather than asking Copilot to "just fix it." Copilot doesn't know your team's intent.
3. **Push the optimized content** to `docs/wiki/<file>.md`.
4. **In Stage 1b:** the optimized content gets copied into `pathfinder-hub/wiki/<repo-name>/<file>.md` as the authoritative version.

## Iteration

Run this prompt 2–3 times per file across different days. The first pass surfaces obvious issues; later passes catch subtler problems. Each run should produce fewer flags as the content stabilizes.

## What this prompt does NOT do

- Generate new documentation from scratch. If a file is missing, use `prompts/04-build-wiki-from-scratch.md` instead.
- Fix code. If you find a bug while reviewing, file a JIRA ticket — don't try to fix it inside this workflow.
- Replace human judgment. Copilot can flag issues; you decide how to address them.
