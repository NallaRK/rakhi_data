# Prompt: Build Cross-Repo Intelligence Documents

## When to use
Stage 1b, after you've collected wikis and manifests from all 6 pilot repos in `pathfinder-hub/`. Produces the cross-repo intelligence files that the MCP server queries to answer questions like "which repos use the `useAuth` hook?" or "what's the deployment order for the KYC feature?"

## Preferred model
**Claude Opus 4.6 (copilot)** — synthesis across many sources, judgment-heavy.

## Files this prompt produces

Four files in `pathfinder-hub/cross-repo/`:

1. `dependency-map.md` — inter-repo dependencies
2. `shared-components-registry.md` — design-system usage matrix
3. `api-contracts-index.md` — all REST endpoints across backend services
4. `domain-glossary.md` — business term → technical component mapping (PO-facing)

## How to run

Clone the `pathfinder-hub` repo locally. Open it in VSCode with the 6 pilot repo wikis and manifests checked in. Open Copilot Chat. Run the prompt below ONCE per file (the prompt has sections for each).

---

## The prompt — dependency-map.md

```
Generate `pathfinder-hub/cross-repo/dependency-map.md` by analyzing all manifests in `pathfinder-hub/manifests/*.json`.

Output structure:

# Dependency Map

Last updated: <today>
Source: 6 manifests in `manifests/*.json`

## Dependency Graph (Mermaid)

```mermaid
graph TD
  mfe-kyc --> kyc-service
  mfe-checkout --> payment-service
  mfe-checkout --> kyc-service
  ...
```

## Detailed Dependencies

### Frontend → Backend

| Frontend Repo | Calls API From | Endpoints Consumed | Risk if Backend Changes |
|---|---|---|---|
| mfe-kyc | kyc-service | 5 endpoints (see api-contracts-index.md) | High — sole consumer |
| mfe-checkout | payment-service, kyc-service | 12 endpoints | High — payment is critical path |

### Frontend → Shared

| Frontend Repo | Shared Packages Used |
|---|---|
| mfe-kyc | @your-org/design-system, @your-org/shared-utils |
| mfe-checkout | @your-org/design-system, @your-org/shared-utils, @your-org/analytics |

### Backend → Backend (if any)

| Service | Calls | Why |
|---|---|---|
| (likely empty for current 6-repo pilot) | | |

## Reverse Dependencies (who depends on what)

### kyc-service is consumed by:
- mfe-kyc (5 endpoints)
- mfe-checkout (2 endpoints)

### @your-org/design-system is consumed by:
- mfe-kyc, mfe-checkout, mfe-client-portal, mfe-admin

## Deployment Order Implications

When changing kyc-service:
1. Verify no breaking changes (API contracts in api-contracts-index.md)
2. If breaking, deploy backend first, frontend second
3. Affected frontends: mfe-kyc, mfe-checkout

When changing @your-org/design-system:
1. Major version bump → all 4 MFE consumers need coordinated update
2. Minor/patch → MFEs pick up via npm at their own cadence

Generation rules:
- Read EVERY file in `pathfinder-hub/manifests/*.json`
- Cross-reference `relatedRepos`, `apiEndpoints.consumedBy`, and `sharedComponents`
- Do NOT invent dependencies — only document what's in the manifests
- If a dependency seems missing, flag with `<!-- VERIFY: kyc-service may also be called by ... -->` rather than asserting

Show the file content for review.
```

---

## The prompt — shared-components-registry.md

```
Generate `pathfinder-hub/cross-repo/shared-components-registry.md` by analyzing usage of `@your-org/design-system` (and any other shared npm packages) across all 4 MFE manifests in `pathfinder-hub/manifests/*.json`.

Output structure:

# Shared Components Registry

Last updated: <today>
Source: 4 React MFE manifests

## Usage Matrix

| Component | mfe-kyc | mfe-checkout | mfe-client-portal | mfe-admin | Total |
|---|---|---|---|---|---|
| Button | 12 | 18 | 8 | 5 | 43 |
| Modal | 4 | 7 | 3 | 2 | 16 |
| FormField | 22 | 15 | 6 | 3 | 46 |
| ... | | | | | |

## High-Risk Components (used in 3+ MFEs)

Changes to these need coordinated rollout.

### Button
- Usage: 43 instances across 4 MFEs
- Recent changes: (check design system repo CHANGELOG)
- Last breaking change: (if known)
- Owner: design-system team

### FormField
...

## Components Used in Only One MFE

These can be modified or removed without cross-repo impact.

| Component | Used in | Consider |
|---|---|---|
| KycSpecificComponent | mfe-kyc only | Should this be in mfe-kyc/local-components, not design system? |

## Components NOT Used

(useful for cleanup — components in design system but no MFE imports)

Generation rules:
- Aggregate `sharedComponents[*].usedIn` across all manifests
- Group by component name
- Count usages per MFE
- Flag components used in 0 MFEs or 1 MFE for cleanup discussion
- Do NOT invent components or usages

Show for review.
```

---

## The prompt — api-contracts-index.md

```
Generate `pathfinder-hub/cross-repo/api-contracts-index.md` by extracting `apiEndpoints` from all manifests in `pathfinder-hub/manifests/*.json`.

Output structure:

# API Contracts Index

Last updated: <today>
Source: 2 Spring Boot manifests + 4 MFE manifests

## All Endpoints (by service)

### kyc-service

| Method | Path | Handler | Consumed By |
|---|---|---|---|
| GET | /api/kyc/forms/{id} | KycController.getKycForm | mfe-kyc/useKycForm |
| POST | /api/kyc/forms | KycController.createKycForm | mfe-kyc/useKycForm |
| ... | | | |

### payment-service
...

## Orphaned Endpoints

Endpoints with no documented frontend consumer:

| Endpoint | Service | Status |
|---|---|---|
| POST /api/internal/payments/reconcile | payment-service | Internal use? Verify |

## Contracts Used by Multiple Frontends

These endpoints have 2+ consumers — changes here are high-risk.

| Endpoint | Consumed By |
|---|---|
| GET /api/kyc/client/{clientId} | mfe-kyc, mfe-checkout |

## Versioning Notes

- All endpoints unversioned currently
- Consider /v1/ prefix for future
- Breaking change protocol: TBD (recommend documenting)

Generation rules:
- Backend manifests are authoritative for endpoints exposed
- Frontend manifests are authoritative for endpoints consumed
- Cross-check: every endpoint a frontend claims to consume should exist in a backend manifest
- Flag mismatches with `<!-- MISMATCH: mfe-kyc claims to consume X but no backend exposes it -->`

Show for review.
```

---

## The prompt — domain-glossary.md

```
Generate `pathfinder-hub/cross-repo/domain-glossary.md` by aggregating `domain-glossary.md` content from each repo's `pathfinder-hub/wiki/{repo}/domain-glossary.md`.

This file is PO-facing. Plain English. No code citations in the main entries (just references).

Output structure:

# Domain Glossary

Last updated: <today>

Use this to find which technical components handle which business concepts.

## A

### Acceptance Criteria (AC)
The conditions that must be true for a JIRA story to be considered complete.
- Where it's tracked: JIRA tickets
- Pathfinder usage: `@story-analyzer` extracts AC and `@code-reviewer` builds coverage matrix

### Account Closure
The process of permanently deactivating a customer's account.
- Technical components: AccountClosureService (in client-service repo)
- Related: KYC re-verification (if account is being reopened)

## C

### Client
A business entity that uses our platform. (NOTE: in code, "client" sometimes refers to an HTTP client — context matters)
- Technical components: Client entity (client-service), useClient hook (multiple MFEs)
- Common confusion: "client" (business) vs "client" (HTTP). Code review should disambiguate.

### KYC Submission
A completed Know-Your-Customer form submitted by a client.
- Technical components: KycSubmission document (kyc-service), KycFormContainer (mfe-kyc)
- Lifecycle: draft → submitted → in_review → approved/rejected

## K

### KYC (Know Your Customer)
Regulatory process for verifying client identity.
- Frontend: mfe-kyc
- Backend: kyc-service
- Common operations: submit, view, copy from prior, approve, reject

## P

### Payment
...

## Generation rules

- Aggregate from `pathfinder-hub/wiki/{repo}/domain-glossary.md` files
- De-duplicate entries (multiple repos may define same term)
- For conflicting definitions, surface both: `<!-- CONFLICT: mfe-kyc defines "client" as X; client-service defines as Y -->`
- Use plain language. This is for product owners and new engineers.
- Order alphabetically
- Cross-reference related terms

Show for review.
```

---

## After running all four prompts

1. **Verify cross-references.** The four files reference each other. Make sure paths resolve.
2. **Commit to `pathfinder-hub/cross-repo/`**.
3. **Set up the quarterly refresh GHA** to re-run these prompts on a schedule (see `workflows/quarterly-refresh.yml` in the zip).

## Maintenance

These four files become stale fastest. Set the refresh cadence aggressively — quarterly at minimum, monthly if your team is reorganizing code frequently.
