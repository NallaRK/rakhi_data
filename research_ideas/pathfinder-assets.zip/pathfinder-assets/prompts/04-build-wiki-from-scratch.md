# Prompt: Build Wiki Content From Scratch

## When to use
For repos where you don't have DeepWiki content to copy in. Common cases:
- New repos created after the initial DeepWiki export
- Repos Devin couldn't analyze (private dependencies, build failures)
- Stage 1b when adding additional repos beyond the initial pilot 6

Produces a `docs/wiki/` folder with the same structure as the DeepWiki-exported repos, generated directly from code.

## Preferred model
**Claude Opus 4.6 (copilot)** — reasoning-heavy task involving codebase synthesis.

## How to run

Open VSCode in the target repo. Open Copilot Chat. Paste the prompt below.

This is a longer-running prompt than the others — Copilot needs to read substantial portions of the codebase.

---

## The prompt

```
This repository has no DeepWiki content. Generate `docs/wiki/` files from scratch using @workspace and codebase analysis.

Produce the following files. Use the existing pathfinder-hub wiki templates as structural guides — they should be at `pathfinder-hub/wiki/_template/` if you have access, otherwise follow the structure outlined below.

## Files to produce

### docs/wiki/overview.md
- One-paragraph "what is this repo" summary
- Tech stack (derived from package.json / build.gradle / pom.xml)
- High-level responsibility within the org
- Entry points (main.tsx, Application.java, etc.)

### docs/wiki/architecture.md
- Directory structure (top 2 levels, with one-line purpose for each)
- Key architectural decisions visible in the code
- State management approach (Redux Toolkit slices? React Query? Spring service layer?)
- Module boundaries

### docs/wiki/components.md (frontend repos)
OR docs/wiki/services.md (backend repos)

For frontend:
- List of significant components (not every file — just the meaningful ones, ~10–20 entries)
- Each entry: name, path, purpose (one sentence), key props/state, used by

For backend:
- List of services with: name, path, methods, dependencies

### docs/wiki/api-contracts.md
- For frontend: list of API endpoints called, organized by service consumed
- For backend: list of endpoints exposed, with request/response shapes
- Authentication/authorization model

### docs/wiki/data-model.md (backend repos only)
- MongoDB collections / database tables
- Document/entity classes with key fields
- Indexes
- Relationships between collections

### docs/wiki/domain-glossary.md
- Business terms used in this codebase (look at class/function names for domain language)
- Map business terms to technical artifacts (e.g., "KYC submission" → `KycSubmission` document)
- Note: This is the PO-facing section. Use plain language.

## Generation rules

1. **Read code before writing docs.** Use @workspace and search/codebase liberally. Each claim in the wiki must be traceable to source code.

2. **Cite file paths.** Every section should reference the file(s) it documents.

3. **One sentence per item.** Wiki entries are reference material, not tutorials. Keep entries short.

4. **Avoid generic explanations.** Don't explain what React or Spring is. Document what THIS repo does.

5. **Flag what you don't understand.** If you encounter code you can't explain confidently, include a `<!-- UNCLEAR: ... -->` marker rather than guessing.

6. **Do NOT include code blocks longer than 10 lines.** Wiki is for understanding, not for copy-paste.

7. **Order by frequency of access.** Within each file, put the most-frequently-needed info at the top.

## Process

1. Start by reading the repo's README.md (if it exists) and package.json/build.gradle
2. List the source directories with `search/codebase`
3. For each file you plan to generate, identify which source files you need to read
4. Write the file, then verify each cited path exists
5. Show me each generated file BEFORE writing to disk

## Output

Show all 5–6 wiki files in your chat response. After I review, write them to `docs/wiki/`.
```

---

## After running

1. **Read every file before committing.** New-from-scratch generation has higher hallucination risk than optimizing existing DeepWiki content.
2. **Address every UNCLEAR marker.** These are gaps that need a human (probably a senior dev on the team) to fill.
3. **Run `prompts/03-optimize-deepwiki-content.md` on each generated file.** That prompt's accuracy verification pass catches issues this prompt missed.
4. **Commit to `docs/wiki/`.**

## Tradeoffs

- Generated-from-scratch wikis are less comprehensive than DeepWiki's auto-generated content. DeepWiki has access to PR history, comments, and call graphs. Copilot's view is limited to the current snapshot.
- Expect to spend 2–4 hours per repo on review and refinement. This is similar effort to the DeepWiki optimization workflow, but starting from less raw material.

## When NOT to use this prompt

- When you have DeepWiki content already — use the optimization prompt instead.
- When the repo is trivial (~5 files, ~200 lines). The wiki overhead isn't worth it.
- When the repo is being deprecated. Document the deprecation in the README, not in a wiki.
