# Prompt: Generate `.github/copilot-instructions.md`

## When to use
Run this prompt ONCE per repo, in VSCode Copilot Chat, after opening the repo in VSCode. Generates `.github/copilot-instructions.md` which encodes the team's coding standards so every Copilot generation in this repo follows them.

## Preferred model
**Claude Opus 4.6 (copilot)** — reasoning-heavy task. GPT-5.2 also works.

## Why this matters
Without `.github/copilot-instructions.md`, every developer's Copilot output varies. Naming conventions, error handling, test patterns, import styles — all drift. This file becomes the team's coding constitution that Copilot reads on every chat turn.

## How to run

Open VSCode in the target repo. Open Copilot Chat. Run Copilot's built-in `/init` command first if you haven't already:

```
/init
```

Then paste the prompt below into Copilot Chat.

---

## The prompt

```
You are setting up Pathfinder for this repository. Your task is to generate `.github/copilot-instructions.md` — the coding standards file that all future Copilot generations in this repo will follow.

Analyze the current repository using @workspace and produce a `.github/copilot-instructions.md` file containing:

## 1. Project Overview
- One paragraph describing what this repo is and does
- Tech stack (languages, frameworks, key libraries) — derive from package.json / build.gradle / pom.xml
- Architecture style (MFE, microservice, monolith, etc.)

## 2. Code Organization
- Directory structure conventions (where do hooks live, where do components live, etc.)
- File naming conventions (look at existing files; what patterns do they follow?)
- Module/component organization

## 3. Coding Standards
Look at 5–10 existing source files and derive:
- Indentation, quote style, trailing comma policy
- TypeScript/Java conventions: strict mode? optional chaining? null vs undefined? checked exceptions?
- Import ordering and grouping
- Error handling patterns (Result types, try/catch conventions, error response shapes)
- Comment style (when to comment, JSDoc/Javadoc usage)

## 4. Patterns Used in This Codebase
For React MFEs, identify:
- State management (Redux Toolkit slice patterns, RTK Query vs React Query)
- Component patterns (container vs presentational, custom hooks for logic)
- Routing conventions
- API client structure

For Java Spring Boot, identify:
- Controller → Service → Repository layering
- DTO usage and mapping (MapStruct? manual?)
- Spring Data MongoDB patterns (@Document, custom repositories)
- Validation approach (Bean Validation, custom validators)
- Exception handling (ControllerAdvice, custom exception types)

## 5. Testing Conventions
- Test file location (`__tests__/`, `test/`, alongside source)
- Test naming convention (look at existing tests)
- Mocking patterns (MSW for frontend, Mockito for Java, etc.)
- Coverage expectations (look for a coverage config)

## 6. Anti-Patterns to Avoid
Look for code that exists but the team appears to be moving away from. Anti-patterns to call out explicitly:
- Deprecated APIs still in use
- Old patterns being phased out
- Common mistakes you can see were corrected in PR history

## 7. Output
Write the final content to `.github/copilot-instructions.md`. Do NOT include implementation details for specific features — only conventions and patterns that apply across the codebase.

## Constraints
- Maximum 400 lines (Copilot reads this on every turn; long files burn context budget)
- Use Markdown headers and code examples
- Be specific. "Use clear naming" is not a standard. "Hooks start with `use`, components use PascalCase, files match the export name" is.
- Cite existing files as examples where useful, but do not paste large code blocks

After generating, show me the file content for review before writing it to disk.
```

---

## After running

1. **Review the output.** Copilot may overstate or hallucinate patterns. Read carefully.
2. **Trim aggressively.** If a section feels generic ("use clean code"), delete it. Specificity is what makes this file useful.
3. **Commit the file** to the repo at `.github/copilot-instructions.md`.
4. **Test it.** Run a Copilot chat asking for a small change. Verify the generated code follows the conventions you just defined.

## Maintenance

Re-run this prompt every 6 months or after a major refactor. The file should evolve with the codebase, not freeze in time.
