# Prompt: Figma Design Extraction (PNG/JPG)

## When to use
Inside the `@design-analyzer` agent, OR as a one-off when you need to manually analyze a Figma attachment without invoking the full agent. Provided here as a standalone prompt for the case where the agent isn't yet set up but you need to extract design intent from a PNG today.

## Required model
**Must be vision-capable.** Choose ONE of:
- Claude Opus 4.6 (copilot)
- Claude Opus 4.7 (copilot)
- GPT-5.2 (copilot)

If you select a non-vision model, the prompt will silently fail — Copilot will respond as if no image was provided.

## How to run

1. In VSCode Copilot Chat, **paste or drag-and-drop the Figma PNG/JPG attachment** into the chat input.
2. Select a vision-capable model (Claude Opus 4.6/4.7 or GPT-5.2) from the model picker.
3. Paste the prompt below.

If you have multiple attachments (e.g., mockup + interaction flow + build spec), upload all of them and reference them in the prompt.

---

## The prompt

```
I have attached Figma design image(s) from JIRA ticket <PROJ-XXXX>. Your task is to extract design intent and map it to our internal design system components.

CRITICAL: Distinguish between what is annotated (ground truth from the design) and what you are inferring (your best guess). The developer needs to know which is which.

## Context

Our design system is at `node_modules/@your-org/design-system/`:
- TypeScript definitions: `dist/*.d.ts`
- Usage examples: `__examples__/` and `stories/`
- Predefined theme tokens (spacing, colors, font sizes) — never invent new tokens

## Analysis steps

### Step 1: Catalog the attachments
For each image, identify:
- Image type: pure visual, annotated screenshot, build spec, interaction flow, prototype frame
- Visible UI elements
- Annotations present (measurements, component callouts, color tokens, font specs)

### Step 2: Map UI elements to design system components

For each identified element, do this lookup:

1. Read `node_modules/@your-org/design-system/dist/index.d.ts` (via @workspace) to see available components
2. Match the visual element to a component by name and visual pattern
3. Check `node_modules/@your-org/design-system/__examples__/<Component>.tsx` for the usage pattern
4. Derive the props from the design

For each match, report:
- Component name (from the design system)
- Props derived (with confidence level for each: annotated / inferred)
- Pattern file to follow

### Step 3: Identify what's missing from the design

Common gaps in PNG/JPG designs:
- Loading states
- Empty states
- Error states
- Responsive/mobile views
- Accessibility annotations
- Interaction details (hover, focus, disabled)

For each gap, do NOT invent. Flag it as a PO clarification needed.

### Step 4: Output

Produce structured output in this format:

# Design Analysis: <JIRA-XXXX>

## Attachments
1. <filename> — <type> — <one-line summary>

## UI Elements

### <Element name>
- **Component match:** `<ComponentName>` from `@your-org/design-system`
- **Source of evidence:** annotated in <filename> / inferred from visual similarity
- **Props derived:**
  - `<propName>="<value>"` (annotated / inferred / default)
- **Pattern file:** `node_modules/@your-org/design-system/__examples__/<ExampleFile>.tsx`
- **Confidence:** High / Medium / Low

## Design Tokens Used
| Token | Value | Source |
|---|---|---|
| theme.spacing.md | 16px | predefined; not annotated |
| theme.colors.primary | (predefined) | annotated |

## Interaction Details
- <interaction>: <description> (annotated / inferred)

## Uncertainties Flagged (NOT in design)

1. **Loading state** — not shown. Default: design system Spinner.
2. **Empty state** — not shown. PO clarification needed.
3. **Error state** — not shown. PO clarification needed.
4. **Mobile breakpoint** — only desktop shown. Apply design system responsive defaults.
5. **Accessibility** — no annotations. Apply design system a11y defaults.

## Recommendations for Implementation
- Use existing components: <list>
- New components needed: <should be empty if design system covers it>
- Custom CSS needed: <should be empty>
- Cross-repo impact: (if any design system component change is required)

## Confidence Summary
- **High confidence:** Annotated values, exact design system matches
- **Medium confidence:** Inferred but with strong visual match
- **Low confidence:** Inferred with weak visual signals

If any element is Low confidence, recommend the developer confirms with the PO before implementation.
```

## Rules — what NOT to do

- **Never invent measurements.** "Looks like 16px padding" is not acceptable. Either it's annotated or it's the design system default.
- **Never invent components.** If a visual element doesn't match any existing component, say so. Don't say "looks like a Button" if you haven't verified the design system has that exact variant.
- **Never silently fill gaps.** Loading states, error states, empty states, mobile views — if not shown, flag them. Do not assume.
- **Never propose custom CSS.** Custom CSS bypasses the design system. If something doesn't fit, recommend a design system addition or PO discussion.
- **Never report High confidence on inferred values.** Inference is by definition Medium or Low confidence.

## Output verification

After Copilot produces the analysis:

1. **Verify each "annotated" claim.** Open the PNG. Is the annotation actually there?
2. **Question every High confidence on a non-annotated value.** This is the most common hallucination pattern.
3. **Check the design system pattern file paths.** Run `ls node_modules/@your-org/design-system/__examples__/` and confirm.
4. **Make sure the gaps are surfaced.** If Copilot didn't flag empty/error/loading states, ask explicitly: "What states are missing from this design?"

## When the agent vs. this prompt

- **Use the `@design-analyzer` agent** during normal Pathfinder workflow (orchestrator invokes it).
- **Use this standalone prompt** when:
  - The agent isn't set up yet (Stage 1a, before agents are added)
  - You're spot-checking the agent's output
  - You need to analyze a design outside of a JIRA ticket context
