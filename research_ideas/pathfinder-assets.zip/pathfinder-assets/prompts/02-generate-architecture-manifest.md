# Prompt: Generate `.github/architecture-manifest.json`

## When to use
Run ONCE per repo during Stage 1a setup. Produces the machine-readable manifest that `@story-analyzer` queries via the `pathfinder-hub` MCP server to identify affected repos.

In Stage 1b, this file becomes auto-synced from `pathfinder-hub/manifests/{repo-name}.json` — but the initial bootstrap is generated here.

## Preferred model
**Claude Opus 4.6 (copilot)** — needs careful analysis of existing code structure.

## How to run

Open VSCode in the target repo. Open Copilot Chat. Paste the prompt below.

After Copilot generates the JSON, **review it carefully** before committing. Hallucinated entries are common.

---

## The prompt

```
Analyze this repository using @workspace and produce a `.github/architecture-manifest.json` file matching the schema below.

The manifest is a machine-readable snapshot of this repo's architecture, consumed by the Pathfinder MCP server to answer cross-repo questions like "which repos need to change for this story?"

## Output Schema

For a React MFE repo (TypeScript + Redux Toolkit + React Query):

{
  "repoName": "<repo-name from git remote>",
  "repoType": "react-mfe",
  "language": "typescript",
  "framework": "react",
  "stateManagement": "redux-toolkit",
  "dataFetching": "react-query",
  "designSystem": "@your-org/design-system",
  
  "components": [
    {
      "name": "KycFormContainer",
      "path": "src/components/KycFormContainer.tsx",
      "type": "container",
      "describes": "main KYC form page; handles submission flow",
      "uses": ["useKycForm", "KycFormHeader", "FormField (design-system)"]
    }
  ],
  
  "hooks": [
    {
      "name": "useKycForm",
      "path": "src/hooks/useKycForm.ts",
      "describes": "manages KYC form state and submission",
      "queries": ["GET /api/kyc/forms/{id}"],
      "mutations": ["POST /api/kyc/forms"]
    }
  ],
  
  "apiEndpoints": [
    {
      "method": "GET",
      "path": "/api/kyc/forms/{id}",
      "calledBy": ["useKycForm"],
      "consumesService": "kyc-service"
    }
  ],
  
  "sharedComponents": [
    {
      "name": "FormField",
      "package": "@your-org/design-system",
      "usedIn": ["KycFormContainer", "KycFormSection"]
    }
  ],
  
  "relatedRepos": [
    {
      "repo": "kyc-service",
      "relationship": "consumes-api"
    },
    {
      "repo": "client-mfe",
      "relationship": "shares-design-system"
    }
  ],
  
  "lastIndexed": "<today's ISO date>"
}

For a Java Spring Boot repo (Java 17 + Spring Data MongoDB):

{
  "repoName": "<repo-name from git remote>",
  "repoType": "java-spring-boot",
  "language": "java",
  "framework": "spring-boot",
  "javaVersion": "17",
  "database": "mongodb",
  
  "controllers": [
    {
      "name": "KycController",
      "path": "src/main/java/com/yourorg/kyc/controller/KycController.java",
      "basePath": "/api/kyc",
      "endpoints": [
        {"method": "GET", "path": "/forms/{id}", "handler": "getKycForm"}
      ]
    }
  ],
  
  "services": [
    {
      "name": "KycService",
      "path": "src/main/java/com/yourorg/kyc/service/KycService.java",
      "usesRepositories": ["KycFormRepository"]
    }
  ],
  
  "mongoCollections": [
    {
      "name": "kyc_submissions",
      "documentClass": "KycSubmission",
      "path": "src/main/java/com/yourorg/kyc/domain/KycSubmission.java",
      "indexes": ["clientId_1_submittedAt_-1"]
    }
  ],
  
  "apiEndpoints": [
    {
      "method": "GET",
      "path": "/api/kyc/forms/{id}",
      "controller": "KycController",
      "consumedBy": ["mfe-kyc"]
    }
  ],
  
  "relatedRepos": [
    {
      "repo": "mfe-kyc",
      "relationship": "consumed-by-frontend"
    }
  ],
  
  "lastIndexed": "<today's ISO date>"
}

## Process

1. List the top-level directories and identify the repo type (react-mfe or java-spring-boot)
2. For each component/hook/controller/service, read the file briefly and extract the minimum metadata to populate the schema
3. Cross-reference: which API endpoints are called by which hooks? Which services use which collections?
4. For `relatedRepos`, infer from imports of @your-org/* packages and API calls to other services

## Constraints

- Only include files that actually exist in the repo
- Do NOT invent endpoints, components, or hooks
- If you cannot determine a field, omit it rather than guess
- `describes` fields should be ONE short sentence each (max 100 chars)
- Output valid JSON

## Output

Show me the generated JSON for review before writing to `.github/architecture-manifest.json`.
```

---

## After running

1. **Verify every entry.** Open a few files cited in the manifest and confirm they match the description.
2. **Check for hallucinated endpoints.** A common failure: Copilot infers "there must be a DELETE endpoint" because it sees GET and POST. Verify.
3. **Commit the file** to `.github/architecture-manifest.json`.
4. **In Stage 1b:** This file gets replaced by an auto-synced copy from `pathfinder-hub`. Don't edit the local copy directly after that point.

## Schema variations

- For repos that don't match react-mfe or java-spring-boot, adapt the schema. Common patterns: shared-utility (npm package), monorepo workspace, infrastructure-as-code repo.
